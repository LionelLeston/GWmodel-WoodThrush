
# Prepare dataset ####
# updated WOTH point count data with offsets calculated. Right
# now there is one record per point count survey, with some point
# count locations having multiple surveys

# First combine the point counts into one file, then get just
# site, lat and long; use site, lat and long to extract the data
# we need for modelling, then rejoin them along with the environmental 
# data to the original surveys
library(dplyr)
library(tidyr)
CompiledFileList<-list.files(path="0_data/raw/WOTH count data", pattern=".csv")
# #36 files

datalist<-c()#empty list to be filled
DIR<-"0_data/raw/WOTH count data"
for (i in CompiledFileList){
  X<-read.csv(paste0(DIR,"/",i),header=TRUE)
  X2<-X[,c("PCODE","PKEY","SS","lat","lon","dt","tm","dis","dur","spp",
           "TSSR","JDAY","DSLS","LCC2","LCC4","TREE","MAXDUR","MAXDIS","key","p","q","A","correction","offset")]
  X3<-unique(X2)
  datalist[[i]]<-X3
}
X.all<-do.call(rbind, datalist)
str(X.all)
save(X.all, file="0_data/raw/WOTH counts combined/AllWOTHcounts.RData")
rm(datalist, X.all, CompiledFileList, DIR, i, X, X2, X3)
gc()
# Load packages and data
library(colorspace)
library(data.table)
library(dplyr)
library(ggplot2)
library(grDevices)
library(gridExtra)
library("GWmodel")
library(maptools)
library(mclust)
library(mefa4)
library(opticut)
library(raster)
library(RColorBrewer)
library(reshape2)
library(rgdal)
library(rgeos)
library(scales)
library(sf)
library(sp)
library(tidyr)

load("0_data/raw/WOTH counts combined/AllWOTHcounts.RData")

SScombo<-unique(X.all[,c("SS","lat","lon")])


#create spatial data frame from regular data frame SScombo to extract GIS data
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

#create point shapefile for all data
X.all2<-SpatialPointsDataFrame(coords=X.all[,c("lon","lat")],data=X.all,proj4string = latlong)
# write a shapefile
writeOGR(X.all2, getwd(),
         "AllWOTHcountsShapefile", driver="ESRI Shapefile")

#just the actual occurrences
X.all.occur<-X.all2[X.all2$spp>0,]
writeOGR(X.all.occur, getwd(),
         "AllWOTHoccurrencesShapefile", driver="ESRI Shapefile")

#convert actual occurrences to polygon for
#updated breeding range in Canada
XY.all.forhull<-as.data.frame(X.all.occur[,c("lon","lat")])
ch <- chull(XY.all.forhull)
coords <- XY.all.forhull[c(ch, ch[1]), ]  # closed polygon

sp_poly <- SpatialPolygons(list(Polygons(list(Polygon(coords)), ID=1)))
# set coordinate reference system with SpatialPolygons(..., proj4string=CRS(...))
# e.g. CRS("+proj=longlat +datum=WGS84")
sp_poly_df <- SpatialPolygonsDataFrame(sp_poly, data=data.frame(ID=1))
plot(X.all.occur, pch=19)
lines(sp_poly_df, col="red")#shows that polygon was created

#Now clip out just the part within Canada
basemap.laea<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap.latlong<-spTransform(basemap.laea, latlong)
Canada<-basemap.latlong[basemap.latlong$COUNTRY=="CAN",]
plot(X.all.occur, pch=19)
lines(sp_poly_df, col="red")#shows that polygon was created
lines(Canada, col="blue")#shows that polygon was created

WOTH.Cdnrange<-raster::intersect(sp_poly_df,Canada)
writeOGR(WOTH.Cdnrange, "0_data/raw/WOTH counts combined/UpdatedCanadianRangeConvexHull", layer="UpdatedCanadianRangeConvexHull", driver="ESRI Shapefile")

#Create polygon through kernel density estimation
#https://mhallwor.github.io/_pages/activities_GenerateTerritories

library(ks)
X.all.asif1territory<-c(X.all.occur)#creates a list of 1
bw<-lapply(X.all.asif1territory, FUN=function(x){ks::Hlscv(x@coords)})

WOTH_kde<-mapply(X.all.asif1territory,bw,
                 SIMPLIFY=FALSE,
                 FUN=function(x,y){
                   raster(kde(x@coords,h=y))
                 })

## ------------------------------------------------------------------------
# This code makes a custom function called getContour. 
# Inputs:
#    kde = kernel density estimate
#    prob = probabily - default is 0.95 (I switched it to 0.9999 for WOTH)

getContour <- function(kde, prob = 0.9999){
  # set all values 0 to NA
  kde[kde == 0]<-NA
  # create a vector of raster values
  kde_values <- raster::getValues(kde)
  # sort values 
  sortedValues <- sort(kde_values[!is.na(kde_values)],decreasing = TRUE)
  # find cumulative sum up to ith location
  sums <- cumsum(as.numeric(sortedValues))
  # binary response is value in the probabily zone or not
  p <- sum(sums <= prob * sums[length(sums)])
  # Set values in raster to 1 or 0
  kdeprob <- raster::setValues(kde, kde_values >= sortedValues[p])
  # return new kde
  return(kdeprob)
}

WOTH_9999kde <- lapply(WOTH_kde,
                     FUN = getContour,prob = 0.9999)

par(mfrow = c(1,2))
plot(WOTH_kde[[1]],legend = FALSE)
plot(WOTH_9999kde[[1]],legend = FALSE)

WOTH_9999poly <- lapply(WOTH_9999kde, 
                      FUN = function(x){
                        x[x==0]<-NA
                        y <- rasterToPolygons(x, dissolve = TRUE)
                        return(y)
                      })


WOTH_9999poly <- mapply(WOTH_9999poly, names(WOTH_9999poly), 
                      SIMPLIFY = FALSE,
                      FUN = function(x,y){x@polygons[[1]]@ID <- y
                      return(x)})


WOTH_9999poly <- do.call(rbind,WOTH_9999poly)

plot(WOTH_9999poly)
lines(sp_poly_df, col="red")#shows that polygon was created
lines(Canada, col="blue")#shows that polygon was created

plot(WOTH.CdnrangeKDE)
lines(sp_poly_df, col="red")#shows that polygon was created
lines(Canada, col="blue")#shows that polygon was created

WOTH.CdnrangeKDE<-raster::intersect(WOTH_9999poly,Canada)
writeOGR(WOTH.CdnrangeKDE, "0_data/raw/WOTH counts combined/UpdatedCanadianRangeKernelDensity", layer="UpdatedCanadianRangeKernelDensity", driver="ESRI Shapefile")

#GIS data extraction


#create spatial point data frame from ALL of the Wood
#Thrush point counts for data extraction
SScombo2<-SpatialPointsDataFrame(coords=SScombo[,c("lon","lat")],data=SScombo,proj4string = latlong)
#Since we are using geographically weighted regression models to identify
#areas where species show distinctly different responses to a set of environmental
#variables than to the same set of variables in other areas (for management 
#purposes), we ideally want to explore an area (e.g. North America) larger
#than the final area that will be broken down into management units (Canada).

#For that reason, we are extracting data influencing bird distribution from
#continental rather than national or provincial layers.

##Elevation (1 km)
mydem <- raster('0_data/raw/NA_Reference_files_ASCII/ClimateNA_DEM.asc')
SScombo2<-spTransform(SScombo2,proj4string(mydem))
SScombo <- cbind(SScombo,"elev"=raster::extract(mydem,SScombo2@coords))
nrow(SScombo[is.na(SScombo$elev),])#265

##MODIS-based landcover (250-m)
nalc2005<-raster("0_data/raw/NA_Land_Cover_2005/NA_LandCover_2005_LCC.img")
SScombo2<-spTransform(SScombo2,proj4string(nalc2005))
SScombo <- cbind(SScombo,"nalc"=raster::extract(nalc2005,SScombo2@coords))
#raster:: needed because we also use tidyr in this script and tidyr has its own "extract" function

## Tree cover (density, Global 30m Landsat Tree Canopy Version 4)
#https://landsat.gsfc.nasa.gov/article/global-30m-landsat-tree-canopy-version-4-released
treecover<-raster("0_data/raw/TreeCover/treecoverlcc1.tif")
plot(treecover)#the colours look like they are backwards: areas I'd
#expect to have less forest cover have been coloured with higher values
SScombo2<-spTransform(SScombo2,proj4string(treecover))
SScombo <- cbind(SScombo,"treecover"=raster::extract(treecover,SScombo2@coords))
SScombo$treecover[which(SScombo$treecover>250)]<-0 # converting values >250 (which represent no forest data) into 0s

## Forest height
height<-raster("0_data/raw/ForestHeightLidar/Simard_Pinto_3DGlobalVeg_L3C.tif")
SScombo2<-spTransform(SScombo2,proj4string(height))
SScombo <- cbind(SScombo,"height"=raster::extract(height,SScombo2@coords))

## Road on/off *Needs to be replaced with a North American layer for Wood Thrush
road<- raster("0_data/raw/roadonoff/roadonoff1.tif")
mr <- c(1, 2500000, 1,  NA, NA, 0)
rcroad <- matrix(mr, ncol=3, byrow=TRUE)
rrc <- reclassify(road,rcroad)
SScombo2<-spTransform(SScombo2,proj4string(road))
SScombo <- cbind(SScombo,"road"=raster::extract(rrc,SScombo2@coords))  
#At this point stop and check the file for missing predictor values
nrow(SScombo)#115566
nrow(SScombo[is.na(SScombo$nalc),])#0
nrow(SScombo[is.na(SScombo$treecover),])#0
nrow(SScombo[is.na(SScombo$height),])#0
nrow(SScombo[is.na(SScombo$road),])#2563

#look at the sites missing road data: it should be mostly U.S. points
roadNA<-SScombo[is.na(SScombo$road),]
roadNA$pcodes<-substr(roadNA$SS,1,5)#extract first 5 characters from each site name
roadNA$pcodes<-as.factor(roadNA$pcodes)
levels(roadNA$pcodes)#the pcodes beginning with BBS are all roadside surveys; the rest are
#from National Wildlife Refuges and are likely to be roadless. Back in SScombo:

SScombo$road<-ifelse(!is.na(SScombo$road), SScombo$road, 
                     ifelse((substr(SScombo$SS,1,3)=="BBS"),1,0))
#Translation: If SScombo$road already has a non-missing value (0 or 1), keep it. Otherwise:
#             Assuming SScombo$road=NA, if it's a BBS station, treat it as a 1 for roadside,
#             otherwise it's a 0 (away from roadside) because it's in a National Wildlife Refuge
nrow(SScombo[is.na(SScombo$road),])#0

## Climate data- upload and resample to 250m resolution to match other layers 
climate2010 <- list.files("0_data/raw/climate/baseline19812010/",pattern="asc$")
setwd("0_data/raw/climate/baseline19812010/")
clim2010 <- stack(raster(climate2010[1]))
for (i in 2:length(climate2010)) { clim2010 <- addLayer(clim2010, raster(climate2010[i]))}

LCC2<-CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")
proj4string(clim2010)<-LCC2

SScombo2<-spTransform(SScombo2,LCC2)
SScombo <- cbind(SScombo,raster::extract(clim2010,SScombo2@coords))

climate.tifs<-list.files(getwd(), pattern="tif$")
#note that since we've already set the climate folder as the working directory, the
#file path has been changed to getwd()
climtif <- stack(raster(climate.tifs[1]))#CMI
climtif <- addLayer(climtif, raster(climate.tifs[2]))#CMIJJA

SScombo2<-spTransform(SScombo2,proj4string(climtif))
#Note that tif files have a different projection from asc files
SScombo <- cbind(SScombo,raster::extract(climtif,SScombo2@coords))


## Landform and topoedaphic 
setwd("E:/CWS Wood Thrush Contract/CHID-GWmodel/")
#reset working directory to R project folder
lf <- raster("0_data/raw/topo/lf_lcc1.tif")
SScombo2<-spTransform(SScombo2,LCC)
SScombo <- cbind(SScombo,"landform"=raster::extract(lf,SScombo2@coords))

SScombo$landform[which(SScombo$landform>0&SScombo$landform<1)]<-0
lf_classes<-data.frame(value=0:9,label=factor(c("water","valley","hilltop.in.valley","headwaters", "ridges.and.peaks","plain","local.ridge.in.plain","local.valley.in.plain","gentle.slopes","steep.slopes")))
lfclass<-lf_classes$label[match(SScombo$landform,lf_classes$value)]
SScombo$landform<-lfclass

#Terrain Ruggedness Index (TRI) is the mean of the absolute differences in elevation between a focal cell and its 8 surrounding cells. It quantifies the total elevation change across the 3×3 cells. Flat areas have a value of zero whereas mountain areas with steep ridges have positive values, which can be greater than 2000m in the Himalaya area. 
#Topographic Position Index (TPI) is the difference between the elevation of a focal cell and the mean of its 8 surrounding cells. Positive and negative values correspond to ridges and valleys, respectively, while zero values correspond generally to flat areas (with the exception of a special case where a focal cell with a value 5 can have surrounding cells with values of 4×1 and 4×9, resulting in a TPI of 0). 
#Roughness is expressed as the largest inter-cell difference of a focal cell and its 8 surrounding cells.
#Slope and aspect are decomposed into 3-dimensional vector components (in the x, y, and z directions) using standard trigonometric operators, and by calculating the resultant vector magnitude within a user-specified moving window size 

TPI <- raster("0_data/raw/topo/tpiLCC.tif")
SScombo <- cbind(SScombo,"TPI"=raster::extract(TPI,SScombo2@coords))
TRI <- raster("0_data/raw/topo/triLCC.tif")
SScombo <- cbind(SScombo,"TRI"=raster::extract(TRI,SScombo2@coords))
slope <- raster("0_data/raw/topo/slopeLCC.tif")
SScombo <- cbind(SScombo,"slope"=raster::extract(slope,SScombo2@coords))
save(SScombo, SScombo2, file="0_data/processed/WOTH_GWmodelDAT.RData")
rm(height, clim2010, climate.tifs, climate2010, climtif, LCC, LCC2, TRI, TPI, treecover, slope)


load("0_data/processed/WOTH_GWmodelDAT.RData")
nrow(SScombo[is.na(SScombo$elev),])#265
nrow(SScombo[is.na(SScombo$AHM),])#265
nrow(SScombo[is.na(SScombo$bFFP),])#265
nrow(SScombo[is.na(SScombo$CMD),])#265
nrow(SScombo[is.na(SScombo$DD_0),])#265
nrow(SScombo[is.na(SScombo$DD_18),])#265
nrow(SScombo[is.na(SScombo$DD18),])#265
nrow(SScombo[is.na(SScombo$DD5),])#265
nrow(SScombo[is.na(SScombo$eFFP),])#265
nrow(SScombo[is.na(SScombo$EMT),])#265
nrow(SScombo[is.na(SScombo$Eref),])#265
nrow(SScombo[is.na(SScombo$EXT),])#265
nrow(SScombo[is.na(SScombo$FFP),])#265
nrow(SScombo[is.na(SScombo$MAP),])#265
nrow(SScombo[is.na(SScombo$MAT),])#265
nrow(SScombo[is.na(SScombo$MCMT),])#265
nrow(SScombo[is.na(SScombo$MSP),])#265
nrow(SScombo[is.na(SScombo$MWMT),])#265
nrow(SScombo[is.na(SScombo$NFFD),])#265
nrow(SScombo[is.na(SScombo$MCMT),])#265
nrow(SScombo[is.na(SScombo$PAS),])#265
nrow(SScombo[is.na(SScombo$PPT_sm),])#265
nrow(SScombo[is.na(SScombo$PPT_wt),])#265
nrow(SScombo[is.na(SScombo$RH),])#265
nrow(SScombo[is.na(SScombo$SHM),])#265
nrow(SScombo[is.na(SScombo$Tave_sm),])#265
nrow(SScombo[is.na(SScombo$Tave_wt),])#265
nrow(SScombo[is.na(SScombo$TD),])#265
nrow(SScombo[is.na(SScombo$CMI),])#281
nrow(SScombo[is.na(SScombo$CMIJJA),])#281
nrow(SScombo[is.na(SScombo$landform),])#0
nrow(SScombo[is.na(SScombo$TPI),])#602
nrow(SScombo[is.na(SScombo$TRI),])#320
nrow(SScombo[is.na(SScombo$slope),])#602

#some missing values but <<<1 % of sites
SS.elevNA<-SScombo[is.na(SScombo$elev),]
SS.elevNA$SS#scattered stops from MBBA, QCATLAS, ACCDC Forested Wetlands, BBSQU, and some in NB or NS

SS.weatherNA<-SScombo[is.na(SScombo$TD),]
SS.weatherNA$SS#scattered stops from MBBA, QCATLAS, ACCDC Forested Wetlands, and BBSQU

SS.weatherNA2<-SScombo[is.na(SScombo$CMI),]
SS.weatherNA2$SS#scattered stops from MBBA, QCATLAS, ACCDC Forested Wetlands, and BBSQU

SS.terrainNA<-SScombo[is.na(SScombo$TRI)|is.na(SScombo$TPI)|is.na(SScombo$slope),]
SS.terrainNA$SS#scattered stops from MBBA, QCATLAS, ACCDC Forested Wetlands, and BBSQU

roughness <- raster("0_data/raw/topo/roughLCC.tif")#roughLCC originally
lcc_crs<-crs(roughness)

#prov <- st_read("E:/CWS Wood Thrush Contract/CHID-subunit-delineation/Recent bird data/Study Area Map/gpr_000a11a_e.shp")
prov <- st_read("E:/CWS Wood Thrush Contract/CHID-GWmodel/0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
basemap.latlong<-st_read("E:/CWS Wood Thrush Contract/CHID-GWmodel/0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots

woth.prov<-prov[prov$PRENAME=="Quebec"|
                  prov$PRENAME=="Ontario"|
                  prov$PRENAME=="Nova Scotia"|
                  prov$PRENAME=="New Brunswick"|
                  prov$PRENAME=="Prince Edward Island",]
woth.prov.new <- st_transform(woth.prov, lcc_crs)
woth.prov.new$area<-st_area(woth.prov.new)
woth.provD<-woth.prov.new %>%
  summarise(area=sum(area))#dissolve basemap.latlong

SS.elevNA.sf<-sf::st_as_sf(SS.elevNA, coords=c("lon","lat"))
p0 <- st_set_crs(SS.elevNA.sf, "+proj=longlat +datum=NAD83 +no_defs")
p0 <- st_transform(p0, lcc_crs)

ggplot() + 
  geom_sf(data = woth.prov.new, size = 0.5, color = "black", fill = "green") + 
  geom_sf(data = p0, size = 1, color = "darkred", fill = "darkred") + 
  ggtitle("Elevation ASC file data missing") + 
  coord_sf()

SS.weatherNA.sf<-sf::st_as_sf(SS.weatherNA, coords=c("lon","lat"))
p1 <- st_set_crs(SS.weatherNA.sf, "+proj=longlat +datum=NAD83 +no_defs")
p1 <- st_transform(p1, lcc_crs)

ggplot() + 
  geom_sf(data = woth.prov.new, size = 0.5, color = "black", fill = "green") + 
  geom_sf(data = p1, size = 1, color = "darkred", fill = "darkred") + 
  ggtitle("Climate ASC file data missing") + 
  coord_sf()

SS.weatherNA2.sf<-sf::st_as_sf(SS.weatherNA2, coords=c("lon","lat"))
p2 <- st_set_crs(SS.weatherNA2.sf, "+proj=longlat +datum=NAD83 +no_defs")
p2 <- st_transform(p2, lcc_crs)

ggplot() + 
  geom_sf(data = woth.prov.new, size = 0.5, color = "black", fill = "green") + 
  geom_sf(data = p2, size = 1, color = "darkred", fill = "darkred") + 
  ggtitle("Climate CMI/CMIJJA file data missing") + 
  coord_sf()

SS.terrainNA.sf<-sf::st_as_sf(SS.terrainNA, coords=c("lon","lat"))
p3 <- st_set_crs(SS.terrainNA.sf, "+proj=longlat +datum=NAD83 +no_defs")
p3 <- st_transform(p3, lcc_crs)

ggplot() + 
  geom_sf(data = woth.prov.new, size = 0.5, color = "black", fill = "green") + 
  geom_sf(data = p3, size = 1, color = "darkred", fill = "darkred") + 
  ggtitle("Terrain data missing") + 
  coord_sf()

ggplot() + 
  geom_sf(data = woth.prov.new[woth.prov.new$PRENAME=="Nova Scotia",], size = 0.5, color = "black", fill = "green") + 
  geom_sf(data = p3, size = 1, color = "darkred", fill = "darkred") + 
  ggtitle("Terrain data missing") + 
  coord_sf()

#It looks like points that are missing data either occur on
#offshore islands or coastlines that are not included in
#or are on the very edge of the climate and terrain layers
roughnessNA<-crop(roughness,basemap.new)

SScombo <- cbind(SScombo,"roughness"=raster::extract(roughnessNA,SScombo2@coords))
save(SScombo, SScombo2, file="0_data/processed/WOTH_GWmodelDAT_2.RData")
#I'm able to crop roughness with a shapefile of Canada
#then extract data to points, but not with the whole layer
#I'm unable to crop roughness with a North America shapefile
#So I will not use "roughness" as a predictor in GW models

#Rejoin site data to point count survey data
load("0_data/raw/WOTH counts combined/AllWOTHcounts.RData")
d1<-merge(X.all, SScombo, by=c("SS","lat","lon"))
save(d1, SScombo, SScombo2, file="0_data/processed/WOTH_GWmodelDAT_joinedtosurveys.RData")


## Optimize landcover class variable with union of samples 
ltnalc <- read.csv("0_data/raw/bamanalytics/lookup/nalcms.csv")
d1$LCclass<-ltnalc$Label[match(d1$nalc, ltnalc$Value)]
d1$LCclass<-factor(as.character(d1$LCclass))
d1<-d1[-which(is.na(d1$LCclass)),]


d1<-d1[complete.cases(d1),]
nrow(d1)#399016
d1$X<-d1$lon
d1$Y<-d1$lat #for sampling points within lat-long blocks below
d1$ABUND<-d1$spp
d1$logoffset<-d1$offset

## Map and sample points
basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap<-spTransform(basemap.latlong, lcc_crs)
#
BCRs<- readOGR("0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#
brandt<- readOGR("0_data/raw/BRANDT_OUTLINE_Dissolve_Proj/BRANDT_OUTLINE_Dissolve_Proj.shp")
# 
# 
latlong<-CRS("+proj=longlat +datum=NAD83 +no_defs")
allpoints <- SpatialPointsDataFrame(coords=cbind(d1$lon,d1$lat), proj4string =latlong, data=d1)
allpoints.lcc <- spTransform(allpoints, CRS=lcc_crs)
allpoints.lcc$ABUND<-allpoints.lcc$spp

spplot(allpoints.lcc,"ABUND",do.log = F,legendEntries=as.character(0:16),
       cex=0.2, alpha=0.5,
       key.space=list(x=0.8,y=0.9,corner=c(0,1)),
       sp.layout=list(basemap))
#This plot is mainly useful for showing where survey points
#are located, not actual distribution or abundance

spplot(allpoints.lcc[which(allpoints.lcc$ABUND>0),],"ABUND",do.log = F,cuts=3,legendEntries=c("1-4","5-8","9-12","13-16"),
       cex=0.2,
       key.space=list(x=0.8,y=0.4,corner=c(0,1)),
       sp.layout=list(basemap))

# spplot(allpoints.lcc[which(allpoints.lcc$ABUND>1),],"ABUND",do.log = F,cuts=14,legendEntries=as.character(2:16),
#        cex=0.2,
#        key.space=list(x=0.9,y=0.7,corner=c(0,1)),
#        sp.layout=list(basemap))

## Obtain 10 quadrant-stratified random samples from full dataset: 

## A function to randomly sample from quadrants defined by latitude and longitude intervals.
sample_quad<-function(data,N=10,Xintervals=100,Yintervals=60,seed=123,onlypres=F){
  set.seed(seed)
  if(onlypres==F){
    maxlongitude<-max(data$X)
    minlongitude<-min(data$X)
    Xwidth<-(maxlongitude-minlongitude)/Xintervals
    Xlimits<-minlongitude+c(0,Xwidth*1:Xintervals)
    
    maxlatitude<-max(data$Y)
    minlatitude<-min(data$Y)
    Ywidth<-(maxlatitude-minlatitude)/Yintervals
    Ylimits<-minlatitude+c(0,Ywidth*1:Yintervals)
    
    ls<-array(NA,dim=c(Xintervals,Yintervals,N))
    for(i in 1:Xintervals){
      data2<-data[which(data$X>Xlimits[i] & data$X<Xlimits[i+1]),]
      for(j in 1:Yintervals){
        data3<-data2[which(data2$Y>Ylimits[j] & data2$Y<Ylimits[j+1]),]
        if(nrow(data3)>0){
          if(nrow(data3)<N){
            ls[i,j,1:nrow(data3)]<-row.names(data3)
          }
          else{
            ls[i,j,]<-row.names(data3[sample(nrow(data3),size=N),]) 
          }
        }
      }
    } 
  }
  
  else{
    data2<-data[which(data$ABUND>0),]
    maxlongitude<-max(data2$X)
    minlongitude<-min(data2$X)
    Xwidth<-(maxlongitude-minlongitude)/Xintervals
    Xlimits<-minlongitude+c(0,Xwidth*1:Xintervals)
    
    maxlatitude<-max(data2$Y)
    minlatitude<-min(data2$Y)
    Ywidth<-(maxlatitude-minlatitude)/Yintervals
    Ylimits<-minlatitude+c(0,Ywidth*1:Yintervals)
    
    ls<-array(NA,dim=c(Xintervals,Yintervals,N))
    for(i in 1:Xintervals){
      data3<-data2[which(data2$X>Xlimits[i] & data2$X<Xlimits[i+1]),]
      for(j in 1:Yintervals){
        data4<-data3[which(data3$Y>Ylimits[j] & data3$Y<Ylimits[j+1]),]
        if(nrow(data4)>0){
          if(nrow(data4)<N){
            ls[i,j,1:nrow(data4)]<-row.names(data4)
          }
          else{
            ls[i,j,]<-row.names(data4[sample(nrow(data4),size=N),]) 
          }
        }
      }
    } 
  }
  
  ls<-c(ls)
  ls<-ls[-which(is.na(ls))]
  out<-match(x=ls,table = row.names(data))
}
## A function to plot sampled points
plot_sampled<-function(obj,index,onlypres=T,show="ABUND"){
  thin_cawa_mm<-obj[index,]
  mmsp <- SpatialPointsDataFrame(coords=cbind(thin_cawa_mm$X,thin_cawa_mm$Y),proj4string =  LCC,data=thin_cawa_mm)
  
  if(onlypres==T){
    spplot(mmsp[which(mmsp$ABUND>0),],show,do.log = F,cuts=4,legendEntries=as.character(1:4),
           key.space=list(x=0.5,y=0.9,corner=c(0,1)),
           sp.layout=list(basemap))
  }
  else{
    spplot(mmsp,show,do.log = F,legendEntries=as.character(0:4),
           key.space=list(x=0.02,y=0.3,corner=c(0,1)),
           sp.layout=list(basemap))
  }
}



## Apply sampling function 10 times
samples<-as.list(rep(NA,10))
names(samples)<-paste0("sample",1:10)

samples$sample1<- sample_quad(d1,seed=1)
samples$sample2<- sample_quad(d1,seed=2)
samples$sample3<- sample_quad(d1,seed=3)
samples$sample4<- sample_quad(d1,seed=4)
samples$sample5<- sample_quad(d1,seed=5)
samples$sample6<- sample_quad(d1,seed=6)
samples$sample7<- sample_quad(d1,seed=7)
samples$sample8<- sample_quad(d1,seed=8)
samples$sample9<- sample_quad(d1,seed=9)
samples$sample10<- sample_quad(d1,seed=10)

d2 <-lapply(samples,function(x){d1[x,]})


union_samples<-union(union(union(union(union(union(union(union(union(samples$sample1,samples$sample2),samples$sample3),samples$sample4),samples$sample5),samples$sample6),samples$sample7),samples$sample8),samples$sample9),samples$sample10)
d1_union<-d1[union_samples,]

ol<- optilevels(y=d1_union$ABUND, x=d1_union$LCclass, dist="poisson", offset=d1_union$logoffset)

d1_union$LCclass2<-d1_union$LCclass
levels(d1_union$LCclass2)<-ol$level[[length(ol$level)]]
#these are a condensed number of classes within which different land cover
#have similar CAWA densities

lc_optim<-function(d2){
  d2$LCclass2<-d2$LCclass
  levels(d2$LCclass2)<-ol$level[[length(ol$level)]]
  return(d2)
}
d2<-lapply(d2,lc_optim)

# # centering  variables for each sample based on their respective means from the union of all samples
centercovs<-function(sample){
  sample$TPI<-scale(sample$TPI)
  sample$TRI<-scale(sample$TRI)
  sample$slope<-scale(sample$slope)
  #sample$roughness<-scale(sample$roughness)
  return(sample)
}
d2<-lapply(d2,centercovs)

# Create spatial dataframe from data samples
LCC<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")
sp_fun<-function(d2){
  sp<- SpatialPointsDataFrame(coords=cbind(d2$X,d2$Y),proj4string = LCC,data=d2)
}

d2sp <- lapply(d2,sp_fun)

save.image("0_data/processed/WOTHsubunits_revisited.RData")

rm(list=setdiff(ls(),c("d1","d1_union","d2","LCC","sample_all","plot_sampled","sample_quad","basemap","d2","d2sp"))) # UPDATE OBJECT LIST HERE!
gc()
#stopped here as of 5:50 PM Dec 10, 2020

load("0_data/processed/WOTHsubunits_revisited.RData")
ls()
nrow(SScombo)#115566
SScombo<-SScombo[!is.na(SScombo$CMIJJA),]
nrow(SScombo)#115285
SScombo<-SScombo[!is.na(SScombo$TD),]
nrow(SScombo)#115285
SScombo<-SScombo[!is.na(SScombo$slope),]
nrow(SScombo)#114807
SScombo<-SScombo[!is.na(SScombo$TRI),]
nrow(SScombo)#114807
SScombo<-SScombo[!is.na(SScombo$elev),]
nrow(SScombo)#114807
#Get correlations among site predictors to eliminate strongly
#correlated predictors
SScombo.cor<-SScombo
SScombo.cor$landform<-NULL
cormat <- round(cor(SScombo.cor[,4:38]),2)
head(cormat)
cormat.df<-data.frame(cormat)
write.csv(cormat.df,file="0_data/processed/cormatdf.WOTH_CHIDstudy.csv")
#most climate variables are strongly correlated with one or more other climate variables
#Wood Thrush study area is relatively small, so climate should be less of an influence
#There are a few recent studies that recommend caution about using climate variables in 
#distribution models: the choice of climate normals and type of model affect the importance
#and effect size of particular climate variables (Jarnevich and Young 2019) and climate may 
#not add much to prediction of bird species after accounting for neighborhood occupancy and 
#geographic coordinates

#If I use climate variables to "smooth" GW estimates, then
#maybe a temperature (MWMT), precipitation (MSP), and drought
#(CMI) metric that aren's strongly correlated with each other

#Other considerations: variability within each predictor
#road=0 or 1 and landform is a categorical variable
mean(SScombo$elev)/sd(SScombo$elev)#1.95
mean(SScombo$nalc)/sd(SScombo$nalc)#1.66
mean(SScombo$treecover)/sd(SScombo$treecover)#1.83
mean(SScombo$height)/sd(SScombo$height)#1.93
mean(SScombo$AHM)/sd(SScombo$AHM)#4.64
mean(SScombo$bFFP)/sd(SScombo$bFFP)#14.07
mean(SScombo$CMD)/sd(SScombo$CMD)#2.32
mean(SScombo$DD_0)/sd(SScombo$DD_0)#2.20
mean(SScombo$DD_18)/sd(SScombo$DD_18)#5.57
mean(SScombo$DD18)/sd(SScombo$DD18)#1.45
mean(SScombo$DD5)/sd(SScombo$DD5)#4.47
mean(SScombo$eFFP)/sd(SScombo$eFFP)#32.18
mean(SScombo$FFP)/sd(SScombo$FFP)#7.16
mean(SScombo$MAP)/sd(SScombo$MAP)#5.56
mean(SScombo$MAT)/sd(SScombo$MAT)#1.83
mean(SScombo$MCMT)/sd(SScombo$MCMT)#-2.36
mean(SScombo$MSP)/sd(SScombo$MSP)#9.36
mean(SScombo$MWMT)/sd(SScombo$MWMT)#9.89
mean(SScombo$NFFD)/sd(SScombo$NFFD)#7.33
mean(SScombo$PAS)/sd(SScombo$PAS)#2.36
mean(SScombo$PPT_sm)/sd(SScombo$PPT_sm)#7.64
mean(SScombo$PPT_wt)/sd(SScombo$PPT_wt)#2.47
mean(SScombo$RH)/sd(SScombo$RH)#15.18
mean(SScombo$SHM)/sd(SScombo$SHM)#6.93
mean(SScombo$Tave_sm)/sd(SScombo$Tave_sm)#8.93
mean(SScombo$Tave_wt)/sd(SScombo$Tave_wt)#-2.17
mean(SScombo$TD)/sd(SScombo$TD)#8.31
mean(SScombo$CMI)/sd(SScombo$CMI)#2.17
mean(SScombo$CMIJJA)/sd(SScombo$CMIJJA)#-0.300
mean(SScombo$TPI)/sd(SScombo$TPI)#-0.06
mean(SScombo$TRI)/sd(SScombo$TRI)#1.05
mean(SScombo$slope)/sd(SScombo$slope)#1.07

#Not much site variation in CMIJJA, slope, TRI, or TPI
summary(SScombo$landform)
#gentle.slopes         headwaters     hilltop.in.valley  local.ridge.in.plain 
#16261                   494                   122                 15817 
#local.valley.in.plain  plain      ridges.and.peaks          steep.slopes 
# 16042                 53026                  1989                  3346 
#valley                 water 
#7705                     5 

rm(allpoints,allpoints.lcc,basemap,basemap.latlong,basemap.latlongD,basemap.new,BCRs,brandt,
   canada,canada.new,centercovs,latlong,lc_optim,LCC,lcc_crs,ltnalc,lf_classes,lfclass,
   m1,mydem,nalc2005,offsetNA,ol,p0,p1,p2,p3,
   roughness,rcroad,road,roadNA,SS.elevNA,SS.terrainNA,SS.terrainNA.sf,SS.weatherNA,SS.weatherNA.sf,SS.weatherNA2,SS.weatherNA2.sf,
   woth.prov,woth.prov.new,woth.provD,X.all)
gc()
ls()
## Specify distance matrices and optimize bandwidths ####
DM <- gw.dist(dp.locat = coordinates(d2sp[[1]]), longlat=TRUE)

# define formulas for bandwidth optimization: no ARU and MIGHT not want to use climate either: for now temperature and precipitation
# looking for warmer (MWMT) and wetter (MSP), which are not strongly correlated
formula_habclim <- formula(ABUND ~ elev + (LCclass2-1) + treecover + height + landform + road + MWMT + MSP + CMI + offset(d2sp[[1]]$logoffset))#no ARU

#The next step is to determine the appropriate neighborhood size for modelling
#Sample points outside of the neighborhood are assumed to be unrelated.
#A neighborhood is generated around each point and then a GW model is run.
#Neighbours that are closer in space are weighted more heavily and have more
#influence on model coefficients.

#The product of these GW models isn't the model coefficients but the size
#of the neighborhood to use. Too small a neighborhood and most points are treated
#as independent of each other. Too large a neighborhood is also unrealistic.
#AIC output is generated at the end of iterations used to find a model solution.
#We can select the best model with the lowest AIC, which may be due to the
#model predictors, the neighborhood size, or some of both.

# bandwidths - use lowest AIC to determine best shape of kernel function
# and whether to use a fixed or adaptive bandwidth
bw.ggwr.exponential.habclim <- bw.ggwr(formula_habclim, data = d2sp[[1]], approach = "AICc", kernel = "exponential", adaptive = FALSE, family="poisson", longlat = TRUE, dMat=DM) 
bw.ggwr.exponential.habclim<-157#AIC=3472 approximately
save(bw.ggwr.exponential.habclim, file="0_data/processed/bw.ggwr.exponential.habclim.RData")
#
bw.ggwr.gaussian.habclim <- bw.ggwr(formula_habclim, data = d2sp[[1]], approach = "AICc", kernel = "gaussian", adaptive = FALSE, family="poisson", longlat = TRUE, dMat=DM) 
bw.ggwr.gaussian.habclim<-421#will be approximately 202, AICc around 3808.421: taking forever to finish
save(bw.ggwr.gaussian.habclim, file="0_data/processed/bw.ggwr.gaussian.habclim.RData")
#
bw.ggwr.exponential.habclim.adap <- bw.ggwr(formula_habclim, data = d2sp[[1]], approach = "AICc", kernel = "exponential", adaptive = TRUE, family="poisson", longlat = TRUE, dMat=DM) 
bw.ggwr.exponential.habclim.adap<-600#AIC around 3793
save(bw.ggwr.exponential.habclim.adap, file="0_data/processed/bw.ggwr.exponential.habclim.adap.RData")
#
bw.ggwr.gaussian.habclim.adap <- bw.ggwr(formula_habclim, data = d2sp[[1]], approach = "AICc", kernel = "gaussian", adaptive = TRUE, family="poisson", longlat = TRUE, dMat=DM) 
bw.ggwr.gaussian.habclim.adap<-613#AICc around 3836: taking forever to finish
save(bw.ggwr.gaussian.habclim.adap, file="0_data/processed/bw.ggwr.gaussian.habclim.adap.RData")
#Based on AICc I will use bw.ggwr.exponential.habclim (nonadap)

#Restart R
memory.limit(size=56000)
library(raster)
library(sf)
library(maptools)
library(dplyr)
library(data.table)
library(reshape2)
library("GWmodel")
library(mefa4)
library(sp)
library(rgdal)
library(opticut)
library(scales)
library(mclust)
library(RColorBrewer)
library(colorspace)
library(ggplot2)
library(gridExtra)
library(tidyr)
load("0_data/processed/WOTHsubunits_revisited.RData")
ls()
write.csv(SScombo, file="0_data/processed/environmentaldataatpoints.csv")

rm(allpoints,allpoints.lcc,basemap,basemap.latlong,basemap.latlongD,basemap.new,BCRs,brandt,
   canada,canada.new,centercovs,latlong,lc_optim,LCC,lcc_crs,ltnalc,m1,offsetNA,ol,p1,p2,p3,
   roughness,SS.terrainNA,SS.terrainNA.sf,SS.weatherNA,SS.weatherNA.sf,SS.weatherNA2,SS.weatherNA2.sf,
   woth.prov,woth.prov.new,woth.provD)
rm(prov.new,provD,prov,X.all)
gc()
ls()
# define functions to fit models
ggwr_sample<-function(formula,index,kernel="gaussian", bw=NULL,adaptive=FALSE,out.model=FALSE,save.path=paste0(getwd(),"/2_outputs/GW sample dataset outputs/")){
  
  d3<-d2sp[[index]]
  
  DM <- gw.dist(dp.locat = coordinates(d3), longlat=TRUE)
  
  samplename<-paste0("ggwr_",kernel,index)
  
  # Fit models
  if(kernel=="gaussian"){
    
    if(is.null(bw)==TRUE){
      bw.gaussian <- bw.ggwr(formula, data = d3, approach = "AICc", kernel = "exponential", adaptive = adaptive, family="poisson", longlat = TRUE, dMat=DM) 
      save(bw.gaussian, file=paste0(save.path,paste0("gaussian/",samplename,"bandwidth.csv")))
    }
    
    else{
      bw.gaussian<-bw
    }
    
    ggwr_gaussian<-ggwr.basic(formula, data = d3, bw = bw.gaussian, kernel = "gaussian", adaptive = adaptive, longlat=TRUE, family="poisson", dMat=DM)
    saveRDS(ggwr_gaussian, file=paste0(save.path,paste0("gaussian/",samplename,".R")))
    if(out.model==TRUE){
      return(ggwr_gaussian)
    }
  }
  
  if(kernel=="exponential"){
    
    if(is.null(bw)==TRUE){
      bw.exponential <- bw.ggwr(formula, data = d3, approach = "AICc", kernel = "exponential", adaptive = adaptive, family="poisson", longlat = TRUE, dMat=DM) 
      save(bw.exponential_grid_east, file=paste0(save.path,paste0("exponential/",samplename,"bandwidth.csv")))
    }
    
    else{
      bw.exponential<-bw
    }
    
    ggwr_exponential<-ggwr.basic(formula, data = d3, bw = bw.exponential, kernel = "exponential", adaptive = adaptive, longlat=TRUE, family="poisson", dMat=DM)
    saveRDS(ggwr_exponential, file=paste0(save.path,paste0("exponential/",samplename,".R")))
    if(out.model==TRUE){
      return(ggwr_exponential)
    }
  }
} 

ggwr_sample_grid<-function(formula,index,kernel="gaussian", bw=NULL,adaptive=FALSE,out.model=FALSE,save.path=paste0(getwd(),"/2_outputs/GW sample dataset outputs/")){
  
  d3<-d2sp[[index]]
  
  grd <-SpatialGrid(points2grid(d3,tolerance=0.49),proj4string = LCC)
  
  DM <- gw.dist(dp.locat = coordinates(d3),rp.locat=coordinates(grd), longlat=TRUE)
  
  samplename<-paste0("ggwr_grid_",kernel,index)
  
  # Fit models
  if(kernel=="gaussian"){
    
    if(is.null(bw)==TRUE){
      bw.gaussian <- bw.ggwr(formula, data = d3, approach = "AICc", kernel = "exponential", adaptive = adaptive, family="poisson", longlat = TRUE, dMat=DM) 
      save(bw.gaussian, file=paste0(save.path,paste0("gaussian/",samplename,"bandwidth.csv")))
    }
    
    else{
      bw.gaussian<-bw
    }
    
    ggwr_gaussian<-ggwr.basic(formula, data = d3, bw = bw.gaussian, kernel = "gaussian", adaptive = adaptive, longlat=TRUE, family="poisson", dMat=DM)
    saveRDS(ggwr_gaussian, file=paste0(save.path,paste0("gaussian/",samplename,"_grid",".R")))
    if(out.model==TRUE){
      return(ggwr_gaussian)
    }
  }
  
  if(kernel=="exponential"){
    
    if(is.null(bw)==TRUE){
      bw.exponential <- bw.ggwr(formula, data = d3, approach = "AICc", kernel = "exponential", adaptive = adaptive, family="poisson", longlat = TRUE, dMat=DM) 
      save(bw.exponential_grid_east, file=paste0(save.path,paste0("exponential/",samplename,"bandwidth.csv")))
    }
    
    else{
      bw.exponential<-bw
    }
    
    ggwr_exponential<-ggwr.basic(formula, data = d3, bw = bw.exponential, kernel = "exponential", adaptive = adaptive, longlat=TRUE, family="poisson", dMat=DM)
    saveRDS(ggwr_exponential, file=paste0(save.path,paste0("exponential/",samplename,"_grid",".R")))
    if(out.model==TRUE){
      return(ggwr_exponential)
    }
  }
} 

# fit models ####
load("0_data/processed/bw.ggwr.exponential.habclim.RData")
formula_habclim <- formula(ABUND ~elev+  (LCclass2-1) + treecover + height + road + MWMT + MSP + CMI + offset(d2sp[[1]]$logoffset))#no ARU
#landform + removed
# ggwr_sample(formula= formula_habclim ,index=1,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# # Error in gw_reg(x, y.adj, W.i * wt2, FALSE, i) : 
# #inv(): matrix seems singular 
# ls()
# rm()
# gc()
# #save.image("0_data/processed/subunits_revisited.RData")
# ggwr_sample(formula= formula_habclim ,index=3,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=5,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=7,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=9,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=2,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=4,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=6,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=8,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()
# ggwr_sample(formula= formula_habclim ,index=10,kernel="gaussian", adaptive=F, bw = bw.ggwr.gaussian.habclim)
# ls()
# rm()
# gc()

#based on results of kernels from Dec. 18-19, use nonadaptive exponential kernel
bw.ggwr.exponential<-157
ggwr_sample(formula= formula_habclim ,index=1,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
gc()
ggwr_sample(formula= formula_habclim ,index=3,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
#save.image("E:/CWS Wood Thrush Contract/CHID-subunit-delineation/subunits_revisited.RData")
gc()
ggwr_sample(formula= formula_habclim ,index=5,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
gc()
ggwr_sample(formula= formula_habclim ,index=7,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
#save.image("E:/CWS Wood Thrush Contract/CHID-subunit-delineation/subunits_revisited.RData")
gc()
ggwr_sample(formula= formula_habclim ,index=9,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
gc()
ggwr_sample(formula= formula_habclim ,index=2,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
#save.image("E:/CWS Wood Thrush Contract/CHID-subunit-delineation/subunits_revisited.RData")
gc()
ggwr_sample(formula= formula_habclim ,index=4,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
gc()
ggwr_sample(formula= formula_habclim ,index=6,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
gc()
ggwr_sample(formula= formula_habclim ,index=8,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
gc()
ggwr_sample(formula= formula_habclim ,index=10,kernel="exponential", adaptive = F, bw = bw.ggwr.exponential)
#save.image("E:/CWS Wood Thrush Contract/CHID-subunit-delineation/subunits_revisited.RData")
gc()

#At this point shut and restart RStudio so that listed objects of type "ggwr" do not 
#include the custom functions. Or just remove those functions from the R workspace
#Restart R and do cluster analysis
