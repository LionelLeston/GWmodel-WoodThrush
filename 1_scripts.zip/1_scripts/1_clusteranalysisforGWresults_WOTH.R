#Restart R
memory.limit(size=56000)
library(colorspace)
library(data.table)
library(dplyr)
library(ggplot2)
library(grDevices)
library(gridExtra)
library("GWmodel")
library(maptools)
library(mclust)
library(mefa4)
library(opticut)
library(raster)
library(RColorBrewer)
library(reshape2)
library(rgdal)
library(rgeos)
library(scales)
library(sf)
library(sp)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=16, family="Arial"),
        axis.text.x=element_text(size=16, angle=90),
        axis.text.y=element_text(size=16),
        axis.title.x=element_text(margin=margin(16,0,0,0)),
        axis.title.y=element_text(margin=margin(0,16,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))


## load back fitted model objects
ggwr_expon1<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential1.R")
ggwr_expon2<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential2.R")
ggwr_expon3<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential3.R")
ggwr_expon4<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential4.R")
ggwr_expon5<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential5.R")
ggwr_expon6<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential6.R")
ggwr_expon7<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential7.R")
ggwr_expon8<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential8.R")
ggwr_expon9<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential9.R")
ggwr_expon10<-readRDS("2_outputs/GW sample dataset outputs/exponential/ggwr_exponential10.R")

latlong<-CRS("+proj=longlat +datum=NAD83 +no_defs")
lcc_crs<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")

## Map and sample points
basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
lcc_crs<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")

basemap<-spTransform(basemap.latlong, lcc_crs)
#BCRs<- readOGR("0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#brandt<- readOGR("0_data/raw/BRANDT_OUTLINE_Dissolve_Proj/BRANDT_OUTLINE_Dissolve_Proj.shp")

ggwr_expon1#some basic information about the GW regression model for sample dataset 1.
#the type of kernel used (bandwidth, shape of kernel function, whether fixed or adaptive).
#quantile values for each of the coefficients.
#some basic measures of model fit (relative and absolute)
latlong<-CRS("+proj=longlat +datum=NAD83 +no_defs")
lcc_crs<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")

points <- SpatialPointsDataFrame(coords=cbind(ggwr_expon1$SDF@coords[,1],ggwr_expon1$SDF@coords[,2]), proj4string =latlong, data=data.frame(ggwr_expon1$SDF))
points.lcc <- spTransform(points, CRS=lcc_crs)

spplot(points.lcc,"elev",do.log = F,legendEntries=as.character(0:16),
       cex=1, 
       key.space=list(x=0.8,y=0.9,corner=c(0,1)),
       sp.layout=list(basemap))
#No points showing up

image(ggwr_expon1$SDF,"CMI")
#image function not working
#Error in image.default(ggwr_gaussian1$SDF, "CMI") : 
#'x' and 'y' values must be finite and non-missing
x<-ggwr_expon1$SDF@coords[,1]
y<-ggwr_expon1$SDF@coords[,2]
CMI<-ggwr_expon1$SDF$CMI

df<-data.frame(x,y,CMI)
str(df)
nrow(df[is.na(df$CMI),])
nrow(df[is.na(df$x),])
nrow(df[is.na(df$y),])
image(df,"CMI")

plot(d2sp$sample1,add=T)
plot(basemap,add=T)


## Averaging GWmodel predictions among samples 
### create "blank" model raster
library(sf)
basemap.laea<-st_read("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
#Initially in Lambert Azimuthal Equal Area projection
lcc_crs<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")
basemap<-st_transform(basemap.laea, lcc_crs)#latlong
woth.studyarea<-basemap[basemap$STATEABB=="CA-ON"|
                          basemap$STATEABB=="CA-QC"|
                          basemap$STATEABB=="CA-PE"|
                          basemap$STATEABB=="CA-NB"|
                          basemap$STATEABB=="CA-NS"|
                          basemap$STATEABB=="US-CT"|
                          basemap$STATEABB=="US-DE"|
                          basemap$STATEABB=="US-IL"|
                          basemap$STATEABB=="US-IN"|
                          basemap$STATEABB=="US-MA"|
                          basemap$STATEABB=="US-MD"|
                          basemap$STATEABB=="US-ME"|
                          basemap$STATEABB=="US-MI"|
                          basemap$STATEABB=="US-MN"|
                          basemap$STATEABB=="US-NH"|
                          basemap$STATEABB=="US-NJ"|
                          basemap$STATEABB=="US-NY"|
                          basemap$STATEABB=="US-OH"|
                          basemap$STATEABB=="US-PA"|
                          basemap$STATEABB=="US-RI"|
                          basemap$STATEABB=="US-VA"|
                          basemap$STATEABB=="US-VT"|
                          basemap$STATEABB=="US-WI"|
                          basemap$STATEABB=="US-WV",]
ggplot() +
  geom_sf(data=woth.studyarea, size = 0.5, color = "blue", fill = "cyan1") +
  ggtitle("Wood Thrush study area") +
  coord_sf()

woth.studyarea.ne<-woth.studyarea[!st_is_empty(woth.studyarea),,drop=FALSE]
#gets rid of polygons with empty geometry
#necessary for converting sf object to sp object
#(shapefile format used in spplot)
woth.studyarea.sp<-as(woth.studyarea.ne, Class="Spatial")

BCRs<- readOGR("E:/CWS Wood Thrush Contract/CHID-GWmodel/0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
BCRs.lcc<-spTransform(BCRs, lcc_crs)

#b2011 <- list.files("0_data/raw/Beaudoin layer",pattern="tif$")
#setwd("0_data/raw/Beaudoin layer")
#bed1<-raster(b2011[1])
#plot(bed1)
#bed1
bed2<-raster(ext=extent(woth.studyarea),crs=crs(woth.studyarea),resolution=1000)
#bed2<-raster(ext=extent(bed1),crs=proj4string(bed1),resolution=1000)
#rm(bed1)
#gc()

#reproject raster to same one used by GGWR points
#lcc_nad83<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#simplest approach
#pr1 <- projectRaster(bed2, crs=lcc_nad83)
### fill raster stacks with estimated coefficient values from GWmodel from each data sample (only from points where species was detected)

files<-list.files("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/",pattern="expon") # select GW model save.files
ls()
latlong<-CRS("+proj=longlat +datum=NAD83 +no_defs")
for(k in 1:length(files)){ 
  gwmod<- readRDS(paste0("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/",files[k]))
  #read in results from a given GW model run on a sample data set
  #to rasterize the point data, they must be in the same projection as the raster
  #currently points in each GGWR object are in lat-long; they need to be reprojected
  #the reason we don't reproject the raster to the points is so that we can set the resolution
  #in metres, although I probably could create the raster and set resolution first,
  #then reproject the raster.
  points <- SpatialPointsDataFrame(coords=cbind(gwmod$SDF@coords[,1],gwmod$SDF@coords[,2]), proj4string =latlong, data=data.frame(gwmod$SDF))
  points.lcc <- spTransform(points, CRS=lcc_crs)
  
  grd<-stack(rasterize(x=points.lcc[which(points.lcc$y>0),],y=bed2,field=points.lcc@data[which(points.lcc$y>0),1],fun=mean))
  #grd<-stack(rasterize(x=gwmod$SDF[which(gwmod$SDF$y>0),],y=pr1,field=gwmod$SDF@data[which(gwmod$SDF$y>0),1],fun=mean))
  #take the first column of GW model spatial data frame [filtered using only y>0], create a raster stack, 
  #and add that column's values to the appropriate location in that raster stack
  #if there is more than one point within a 1-km cell of the raster, take the mean value of the predictor 
  #among all the points in that cell.
  for (i in 2:13) {grd <- addLayer(grd, rasterize(x=points.lcc[which(points.lcc$y>0),],y=bed2,field=points.lcc@data[which(points.lcc$y>0),i],fun=mean))} # habitat covariates are columns in the SpatialPointsDataFrame
  #for (i in 2:13) {grd <- addLayer(grd, rasterize(x=gwmod$SDF[which(gwmod$SDF$y>0),],y=pr1,field=gwmod$SDF@data[which(gwmod$SDF$y>0),i],fun=mean))} # habitat covariates are columns in the SpatialPointsDataFrame
  #then add layers to that raster stack, one for each habitat variable column in the spatial data frame.
  #for a given predictor, if there is more than one point within a 1-km cell of the raster, take the  
  #mean value of that predictor among all the points in that cell.
  names(grd)<-names(points.lcc)[1:13]
  #names(grd)<-names(gwmod$SDF)[1:13]
  
  assign(x=paste0("grid",k),grd)
  rm(grd,gwmod)
  gc()
}


### Average coefficient estimates within each raster cell

set<-ls()[grep("grid",ls())]
z<-mean(stack(lapply(mget(set),function(x){x[[1]]})),na.rm=TRUE)
for(i in 2:nlayers(grid1)){
  z<-addLayer(z,mean(stack(lapply(mget(set),function(x){x[[i]]})),na.rm=TRUE))
}
names(z)<-names(grid1)
writeRaster(z, filename="E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/means.grd", format="raster",overwrite=TRUE)

stack1<-stack("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/means.grd")
stack1
plot(stack1)
plot(stack1[["elev"]])
#I see coloured points not whole coloured rasters

# Clustering based on mean response of Wood Thrush to overall environment####
# Using 10 sample data sets

## Extract data from grid cells into table
df1<-as.data.frame(stack1,na.rm=TRUE,xy=T)
names(df1)
head(df1)
nrow(df1)
#1621 sampled points with 1 or more Wood Thrush
#points contain GW coefficients for those variables that
#were used in GW models. No site ID preserved. 
#Points projection = "+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 
#+lat_2=77 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs". I presume
#you can reproject these points to lat/long to link them
#with point count locations in original file
write.csv(df1, "2_outputs/GW sample dataset outputs/exponential/GWmodelcoefficientsatsampledpointswithWOTH.csv")

#13 predictors in df1: 10 to do with veg or land use or elevation
# based on BIC, when modelling a max of 3 clusters, 2 clusters gives a higher BIC therefore is "better"
# explanation of why highest BIC is best model in Mclust: https://stats.stackexchange.com/questions/237220/mclust-model-selection 

range(df1$x)#-41425.44 2321574.56
range(df1$y)#5717234 6847234

#How Wood Thrush responds to a single variable
range(df1$elev)#-0.003868121  0.007960841
rbPal <- colorRampPalette(c('red','blue'))
df1$Col <- rbPal(10)[as.numeric(cut(df1$elev,breaks = 10))]

spdf1<-SpatialPointsDataFrame(coords=df1[,14:15],proj4string = CRS(proj4string(stack1)), data=data.frame(Classification=as.factor(df1$Col)))
spplot(spdf1, 
       sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
spplot(spdf1, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))

## Create raster with classifications from clustering model:

#Just Two Clusters
mclustBIC2<- mclustBIC(data=df1[,3:12],G=1:2)
mclustMOD2<- Mclust(data=df1[,3:12],G=1:2, x=mclustBIC2) 
spdf2<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD2$classification)))

writeOGR(spdf2, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.2cluster",
         "AllSampledPointsWithWOTH.2cluster", driver="ESRI Shapefile")

#spplot(spdf2, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf2, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters2.png')
spplot(spdf2, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters2.png')
spplot(spdf2, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Three clusters
mclustBIC3<- mclustBIC(data=df1[,3:12],G=1:3)
mclustMOD3<- Mclust(data=df1[,3:12],G=1:3, x=mclustBIC3) 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1
spdf3<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD3$classification)))

writeOGR(spdf3, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.3cluster",
         "AllSampledPointsWithWOTH.3cluster", driver="ESRI Shapefile")
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters3.png')
spplot(spdf3, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters3.png')
spplot(spdf3, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Four Clusters
mclustBIC4<- mclustBIC(data=df1[,3:12],G=1:4)
mclustMOD4<- Mclust(data=df1[3:12],G=1:4, x=mclustBIC4) 
spdf4<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD4$classification)))

writeOGR(spdf4, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.4cluster",
         "AllSampledPointsWithWOTH.4cluster", driver="ESRI Shapefile")
#spplot(spdf4, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf4, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters4.png')
spplot(spdf4, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters4.png')
spplot(spdf4, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Five Clusters
mclustBIC5<- mclustBIC(data=df1[,3:12],G=1:5)
mclustMOD5<- Mclust(data=df1[,3:12],G=1:5, x=mclustBIC5) 
spdf5<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD5$classification)))

writeOGR(spdf5, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.5cluster",
         "AllSampledPointsWithWOTH.5cluster", driver="ESRI Shapefile")
#spplot(spdf5, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf5, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters5.png')
spplot(spdf5, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters5.png')
spplot(spdf5, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Six Clusters
mclustBIC6<- mclustBIC(data=df1[,3:12],G=1:6)
mclustMOD6<- Mclust(data=df1[,3:12],G=1:6, x=mclustBIC6) 
spdf6<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD6$classification)))

writeOGR(spdf6, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.6cluster",
         "AllSampledPointsWithWOTH.6cluster", driver="ESRI Shapefile")
#spplot(spdf6, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf6, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters6.png')
spplot(spdf6, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters6.png')
spplot(spdf6, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Seven Clusters
mclustBIC7<- mclustBIC(data=df1[,3:12],G=1:7)
mclustMOD7<- Mclust(data=df1[,3:12],G=1:7, x=mclustBIC7) 
spdf7<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD7$classification)))

writeOGR(spdf7, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.7cluster",
         "AllSampledPointsWithWOTH.7cluster", driver="ESRI Shapefile")
#spplot(spdf7, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf7, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters7.png')
spplot(spdf7, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters7.png')
spplot(spdf7, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Eight Clusters
mclustBIC8<- mclustBIC(data=df1[,3:12],G=1:8)
mclustMOD8<- Mclust(data=df1[,3:12],G=1:8, x=mclustBIC8) 
spdf8<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD8$classification)))

writeOGR(spdf8, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.8cluster",
         "AllSampledPointsWithWOTH.8cluster", driver="ESRI Shapefile")
#spplot(spdf8, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf8, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters8.png')
spplot(spdf8, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters8.png')
spplot(spdf8, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

#Nine Clusters
mclustBIC9<- mclustBIC(data=df1[,3:12],G=1:9)
mclustMOD9<- Mclust(data=df1[,3:12],G=1:9, x=mclustBIC9) 
#summary(mclustMOD9)
#plot(mclustMOD9)#Selection: 1
spdf9<-SpatialPointsDataFrame(coords=df1[,1:2],proj4string = CRS(proj4string(stack1)),data=data.frame(Classification=as.factor(mclustMOD9$classification)))

writeOGR(spdf9, "2_outputs/GW sample dataset outputs/exponential/AllSampledPointsWithWOTH.9cluster",
         "AllSampledPointsWithWOTH.9cluster", driver="ESRI Shapefile")
#spplot(spdf9, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf9, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps/clusters9.png')
spplot(spdf9, auto.key=FALSE, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)))
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps/clusters9.png')
spplot(spdf9, auto.key=FALSE, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)))
dev.off()

df1$mclust2<-spdf2$Classification
df1$mclust3<-spdf3$Classification
df1$mclust4<-spdf4$Classification
df1$mclust5<-spdf5$Classification
df1$mclust6<-spdf6$Classification
df1$mclust7<-spdf7$Classification
df1$mclust8<-spdf8$Classification
df1$mclust9<-spdf9$Classification
write.csv(df1, "2_outputs/GW sample dataset outputs/exponential/GWmodelcoefficientsatsampledpointswithWOTHclusterassignmentadded.csv")


#create multi-panel plot from PNG files
library(magick)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters BCR maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "2", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/ggwr_cluster_bcr_collage.jpg",
    quality = 100
  )

pngfiles2 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH clusters prov maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles2) %>%
  magick::image_montage(tile = "2", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/ggwr_cluster_prov_collage.jpg",
    quality = 100
  )

#Cluster analyses based on individual data sets
#ggwr_expon1

latlong<-CRS("+proj=longlat +datum=NAD83 +no_defs")
lcc_crs<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")

library(sf)
basemap.laea<-st_read("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
#Initially in Lambert Azimuthal Equal Area projection
lcc_crs<-CRS( "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")
basemap<-st_transform(basemap.laea, lcc_crs)#latlong
woth.studyarea<-basemap[basemap$STATEABB=="CA-ON"|
                          basemap$STATEABB=="CA-QC"|
                          basemap$STATEABB=="CA-PE"|
                          basemap$STATEABB=="CA-NB"|
                          basemap$STATEABB=="CA-NS"|
                          basemap$STATEABB=="US-CT"|
                          basemap$STATEABB=="US-DE"|
                          basemap$STATEABB=="US-IL"|
                          basemap$STATEABB=="US-IN"|
                          basemap$STATEABB=="US-MA"|
                          basemap$STATEABB=="US-MD"|
                          basemap$STATEABB=="US-ME"|
                          basemap$STATEABB=="US-MI"|
                          basemap$STATEABB=="US-MN"|
                          basemap$STATEABB=="US-NH"|
                          basemap$STATEABB=="US-NJ"|
                          basemap$STATEABB=="US-NY"|
                          basemap$STATEABB=="US-OH"|
                          basemap$STATEABB=="US-PA"|
                          basemap$STATEABB=="US-RI"|
                          basemap$STATEABB=="US-VA"|
                          basemap$STATEABB=="US-VT"|
                          basemap$STATEABB=="US-WI"|
                          basemap$STATEABB=="US-WV",]

woth.studyarea.ne<-woth.studyarea[!st_is_empty(woth.studyarea),,drop=FALSE]
#gets rid of polygons with empty geometry
#necessary for converting sf object to sp object
#(shapefile format used in spplot)
woth.studyarea.sp<-as(woth.studyarea.ne, Class="Spatial")

BCRs<- readOGR("E:/CWS Wood Thrush Contract/CHID-GWmodel/0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
BCRs.lcc<-spTransform(BCRs, lcc_crs)

str(ggwr_expon1$SDF@data)
names(ggwr_expon1$SDF@data)
str(ggwr_expon1$SDF@coords)#first column=x (long), second column=y (lat)

#Three clusters
#GGWR_EXPON_1
WOTHpts.gw.exp.1.xy<-ggwr_expon1$SDF@coords[,1:2]
WOTHpts.gw.exp.1.pred<-ggwr_expon1$SDF@data[,1:10]

WOTHpts.gw.exp.1.Y<-ggwr_expon1$SDF@data[,14]
WOTHpts.gw.exp.1<-cbind(WOTHpts.gw.exp.1.xy, WOTHpts.gw.exp.1.pred, WOTHpts.gw.exp.1.Y)
names(WOTHpts.gw.exp.1)
str(WOTHpts.gw.exp.1)
WOTHpts.gw.exp.1<-WOTHpts.gw.exp.1[WOTHpts.gw.exp.1$WOTHpts.gw.exp.1.Y>0,]
names(WOTHpts.gw.exp.1)
str(WOTHpts.gw.exp.1)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.1[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.1[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.1[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.1.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 1")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.1.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 1")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.1.clust<-cbind(WOTHpts.gw.exp.1, cluster.assignment)

WOTHpts.gw.exp.1.clust.gath<-WOTHpts.gw.exp.1.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

library(Rmisc)
# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.1.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG1<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 1") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.1.effectsize.3clust.jpeg", plot=GG1, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG1b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 1") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.1.effectsize.3clust_minuslcc.jpeg", plot=GG1b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_2
WOTHpts.gw.exp.2.xy<-ggwr_expon2$SDF@coords[,1:2]
WOTHpts.gw.exp.2.pred<-ggwr_expon2$SDF@data[,1:10]

WOTHpts.gw.exp.2.Y<-ggwr_expon2$SDF@data[,14]
WOTHpts.gw.exp.2<-cbind(WOTHpts.gw.exp.2.xy, WOTHpts.gw.exp.2.pred, WOTHpts.gw.exp.2.Y)
names(WOTHpts.gw.exp.2)
str(WOTHpts.gw.exp.2)
WOTHpts.gw.exp.2<-WOTHpts.gw.exp.2[WOTHpts.gw.exp.2$WOTHpts.gw.exp.2.Y>0,]
names(WOTHpts.gw.exp.2)
str(WOTHpts.gw.exp.2)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.2[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.2[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.2[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.2.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 2")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.2.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 2")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.2.clust<-cbind(WOTHpts.gw.exp.2, cluster.assignment)

WOTHpts.gw.exp.2.clust.gath<-WOTHpts.gw.exp.2.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.2.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG2<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 2") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.2.effectsize.3clust.jpeg", plot=GG2, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG2b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 2") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.2.effectsize.3clust_minuslcc.jpeg", plot=GG2b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_3
WOTHpts.gw.exp.3.xy<-ggwr_expon3$SDF@coords[,1:2]
WOTHpts.gw.exp.3.pred<-ggwr_expon3$SDF@data[,1:10]

WOTHpts.gw.exp.3.Y<-ggwr_expon3$SDF@data[,14]
WOTHpts.gw.exp.3<-cbind(WOTHpts.gw.exp.3.xy, WOTHpts.gw.exp.3.pred, WOTHpts.gw.exp.3.Y)
names(WOTHpts.gw.exp.3)
str(WOTHpts.gw.exp.3)
WOTHpts.gw.exp.3<-WOTHpts.gw.exp.3[WOTHpts.gw.exp.3$WOTHpts.gw.exp.3.Y>0,]
names(WOTHpts.gw.exp.3)
str(WOTHpts.gw.exp.3)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.3[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.3[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.3[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.3.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 3")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.3.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 3")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.3.clust<-cbind(WOTHpts.gw.exp.3, cluster.assignment)

WOTHpts.gw.exp.3.clust.gath<-WOTHpts.gw.exp.3.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.3.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG3<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 3") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.3.effectsize.3clust.jpeg", plot=GG3, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG3b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 3") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.3.effectsize.3clust_minuslcc.jpeg", plot=GG3b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_4
WOTHpts.gw.exp.4.xy<-ggwr_expon4$SDF@coords[,1:2]
WOTHpts.gw.exp.4.pred<-ggwr_expon4$SDF@data[,1:10]

WOTHpts.gw.exp.4.Y<-ggwr_expon4$SDF@data[,14]
WOTHpts.gw.exp.4<-cbind(WOTHpts.gw.exp.4.xy, WOTHpts.gw.exp.4.pred, WOTHpts.gw.exp.4.Y)
names(WOTHpts.gw.exp.4)
str(WOTHpts.gw.exp.4)
WOTHpts.gw.exp.4<-WOTHpts.gw.exp.4[WOTHpts.gw.exp.4$WOTHpts.gw.exp.4.Y>0,]
names(WOTHpts.gw.exp.4)
str(WOTHpts.gw.exp.4)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.4[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.4[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.4[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.4.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 4")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.4.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 4")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.4.clust<-cbind(WOTHpts.gw.exp.4, cluster.assignment)

WOTHpts.gw.exp.4.clust.gath<-WOTHpts.gw.exp.4.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.4.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG4<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 4") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.4.effectsize.3clust.jpeg", plot=GG4, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG4b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 4") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.4.effectsize.3clust_minuslcc.jpeg", plot=GG4b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_5
WOTHpts.gw.exp.5.xy<-ggwr_expon5$SDF@coords[,1:2]
WOTHpts.gw.exp.5.pred<-ggwr_expon5$SDF@data[,1:10]

WOTHpts.gw.exp.5.Y<-ggwr_expon5$SDF@data[,14]
WOTHpts.gw.exp.5<-cbind(WOTHpts.gw.exp.5.xy, WOTHpts.gw.exp.5.pred, WOTHpts.gw.exp.5.Y)
names(WOTHpts.gw.exp.5)
str(WOTHpts.gw.exp.5)
WOTHpts.gw.exp.5<-WOTHpts.gw.exp.5[WOTHpts.gw.exp.5$WOTHpts.gw.exp.5.Y>0,]
names(WOTHpts.gw.exp.5)
str(WOTHpts.gw.exp.5)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.5[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.5[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.5[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.5.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 5")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.5.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 5")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.5.clust<-cbind(WOTHpts.gw.exp.5, cluster.assignment)

WOTHpts.gw.exp.5.clust.gath<-WOTHpts.gw.exp.5.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.5.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG5<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 5") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.5.effectsize.3clust.jpeg", plot=GG5, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG5b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 5") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.5.effectsize.3clust_minuslcc.jpeg", plot=GG5b, width=12, height=6, units=c("in"), dpi=300)



#GGWR_EXPON_6
WOTHpts.gw.exp.6.xy<-ggwr_expon6$SDF@coords[,1:2]
WOTHpts.gw.exp.6.pred<-ggwr_expon6$SDF@data[,1:10]

WOTHpts.gw.exp.6.Y<-ggwr_expon6$SDF@data[,14]
WOTHpts.gw.exp.6<-cbind(WOTHpts.gw.exp.6.xy, WOTHpts.gw.exp.6.pred, WOTHpts.gw.exp.6.Y)
names(WOTHpts.gw.exp.6)
str(WOTHpts.gw.exp.6)
WOTHpts.gw.exp.6<-WOTHpts.gw.exp.6[WOTHpts.gw.exp.6$WOTHpts.gw.exp.6.Y>0,]
names(WOTHpts.gw.exp.6)
str(WOTHpts.gw.exp.6)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.6[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.6[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.6[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.6.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 6")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.6.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 6")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.6.clust<-cbind(WOTHpts.gw.exp.6, cluster.assignment)

WOTHpts.gw.exp.6.clust.gath<-WOTHpts.gw.exp.6.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.6.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG6<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 6") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.6.effectsize.3clust.jpeg", plot=GG6, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG6b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 6") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.6.effectsize.3clust_minuslcc.jpeg", plot=GG6b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_7
WOTHpts.gw.exp.7.xy<-ggwr_expon7$SDF@coords[,1:2]
WOTHpts.gw.exp.7.pred<-ggwr_expon7$SDF@data[,1:10]

WOTHpts.gw.exp.7.Y<-ggwr_expon7$SDF@data[,14]
WOTHpts.gw.exp.7<-cbind(WOTHpts.gw.exp.7.xy, WOTHpts.gw.exp.7.pred, WOTHpts.gw.exp.7.Y)
names(WOTHpts.gw.exp.7)
str(WOTHpts.gw.exp.7)
WOTHpts.gw.exp.7<-WOTHpts.gw.exp.7[WOTHpts.gw.exp.7$WOTHpts.gw.exp.7.Y>0,]
names(WOTHpts.gw.exp.7)
str(WOTHpts.gw.exp.7)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.7[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.7[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.7[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.7.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 7")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.7.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 7")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.7.clust<-cbind(WOTHpts.gw.exp.7, cluster.assignment)

WOTHpts.gw.exp.7.clust.gath<-WOTHpts.gw.exp.7.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.7.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG7<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 7") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.7.effectsize.3clust.jpeg", plot=GG7, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG7b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 7") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.7.effectsize.3clust_minuslcc.jpeg", plot=GG7b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_8
WOTHpts.gw.exp.8.xy<-ggwr_expon8$SDF@coords[,1:2]
WOTHpts.gw.exp.8.pred<-ggwr_expon8$SDF@data[,1:10]

WOTHpts.gw.exp.8.Y<-ggwr_expon8$SDF@data[,14]
WOTHpts.gw.exp.8<-cbind(WOTHpts.gw.exp.8.xy, WOTHpts.gw.exp.8.pred, WOTHpts.gw.exp.8.Y)
names(WOTHpts.gw.exp.8)
str(WOTHpts.gw.exp.8)
WOTHpts.gw.exp.8<-WOTHpts.gw.exp.8[WOTHpts.gw.exp.8$WOTHpts.gw.exp.8.Y>0,]
names(WOTHpts.gw.exp.8)
str(WOTHpts.gw.exp.8)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.8[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.8[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.8[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.8.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 8")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.8.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 8")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.8.clust<-cbind(WOTHpts.gw.exp.8, cluster.assignment)

WOTHpts.gw.exp.8.clust.gath<-WOTHpts.gw.exp.8.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.8.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG8<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 8") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.8.effectsize.3clust.jpeg", plot=GG8, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG8b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 8") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.8.effectsize.3clust_minuslcc.jpeg", plot=GG8b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_9
WOTHpts.gw.exp.9.xy<-ggwr_expon9$SDF@coords[,1:2]
WOTHpts.gw.exp.9.pred<-ggwr_expon9$SDF@data[,1:10]

WOTHpts.gw.exp.9.Y<-ggwr_expon9$SDF@data[,14]
WOTHpts.gw.exp.9<-cbind(WOTHpts.gw.exp.9.xy, WOTHpts.gw.exp.9.pred, WOTHpts.gw.exp.9.Y)
names(WOTHpts.gw.exp.9)
str(WOTHpts.gw.exp.9)
WOTHpts.gw.exp.9<-WOTHpts.gw.exp.9[WOTHpts.gw.exp.9$WOTHpts.gw.exp.9.Y>0,]
names(WOTHpts.gw.exp.9)
str(WOTHpts.gw.exp.9)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.9[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.9[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.9[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-19500,2322000), ylim=c(5717000,6947500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.9.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 9")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.9.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 9")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.9.clust<-cbind(WOTHpts.gw.exp.9, cluster.assignment)

WOTHpts.gw.exp.9.clust.gath<-WOTHpts.gw.exp.9.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.9.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG9<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 9") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.9.effectsize.3clust.jpeg", plot=GG9, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG9b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 9") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.9.effectsize.3clust_minuslcc.jpeg", plot=GG9b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_10
WOTHpts.gw.exp.10.xy<-ggwr_expon10$SDF@coords[,1:2]
WOTHpts.gw.exp.10.pred<-ggwr_expon10$SDF@data[,1:10]

WOTHpts.gw.exp.10.Y<-ggwr_expon10$SDF@data[,14]
WOTHpts.gw.exp.10<-cbind(WOTHpts.gw.exp.10.xy, WOTHpts.gw.exp.10.pred, WOTHpts.gw.exp.10.Y)
names(WOTHpts.gw.exp.10)
str(WOTHpts.gw.exp.10)
WOTHpts.gw.exp.10<-WOTHpts.gw.exp.10[WOTHpts.gw.exp.10$WOTHpts.gw.exp.10.Y>0,]
names(WOTHpts.gw.exp.10)
str(WOTHpts.gw.exp.10)

mclustBIC3<- mclustBIC(data=WOTHpts.gw.exp.10[,3:12],G=1:3)
mclustMOD3<- Mclust(data=WOTHpts.gw.exp.10[,3:12],G=1:3, x=mclustBIC3, modelName = "VVV") 
summary(mclustMOD3)
plot(mclustMOD3)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.10[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD3$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-110500,2322000), ylim=c(5717000,61047500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.10.clusters3.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 10")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GGWR.expon.10.clusters3.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 10")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD3$classification
WOTHpts.gw.exp.10.clust<-cbind(WOTHpts.gw.exp.10, cluster.assignment)

WOTHpts.gw.exp.10.clust.gath<-WOTHpts.gw.exp.10.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 105%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.10.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG10<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 10") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.10.effectsize.3clust.jpeg", plot=GG10, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG10b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 10") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/GW.expon.10.effectsize.3clust_minuslcc.jpeg", plot=GG10b, width=12, height=6, units=c("in"), dpi=300)

#create multi-panel plot from PNG files
library(magick)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/Provincial maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/indivset_provmap_3clusters_collage.jpg",
    quality = 100
  )


pngfiles1b <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/BCR maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles1b) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/indivset_BCRmap_3clusters_collage.jpg",
    quality = 100
  )

pngfiles2 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/Effect Size Minus Land Cover",
    recursive = TRUE,
    pattern = "\\.jpeg$",
    full.names = T
  )

magick::image_read(pngfiles2) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpeg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/indivset_effectsize_3clusters_collage.jpg",
    quality = 100
  )


pngfiles2b <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/Effect Size Incl Land Cover",
    recursive = TRUE,
    pattern = "\\.jpeg$",
    full.names = T
  )

magick::image_read(pngfiles2b) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpeg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/indivset_effectsizelandcover_3clusters_collage.jpg",
    quality = 100
  )

pngfiles3 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/BIC plots",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles3) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("png") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 3 clust/indivset_BICplots_3clusters_collage.jpg",
    quality = 100
  )


#Five clusters
#GGWR_EXPON_1
WOTHpts.gw.exp.1.xy<-ggwr_expon1$SDF@coords[,1:2]
WOTHpts.gw.exp.1.pred<-ggwr_expon1$SDF@data[,1:10]

WOTHpts.gw.exp.1.Y<-ggwr_expon1$SDF@data[,14]
WOTHpts.gw.exp.1<-cbind(WOTHpts.gw.exp.1.xy, WOTHpts.gw.exp.1.pred, WOTHpts.gw.exp.1.Y)
names(WOTHpts.gw.exp.1)
str(WOTHpts.gw.exp.1)
WOTHpts.gw.exp.1<-WOTHpts.gw.exp.1[WOTHpts.gw.exp.1$WOTHpts.gw.exp.1.Y>0,]
names(WOTHpts.gw.exp.1)
str(WOTHpts.gw.exp.1)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.1[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.1[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.1[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.1.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 1")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.1.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 1")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.1.clust<-cbind(WOTHpts.gw.exp.1, cluster.assignment)
library(tidyr)
library(plyr)
library(dplyr)
WOTHpts.gw.exp.1.clust.gath<-WOTHpts.gw.exp.1.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

library(Rmisc)
pd<-position_dodge(0.1)
# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.1.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG1<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 1") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.1.effectsize.5clust.jpeg", plot=GG1, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG1b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 1") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.1.effectsize.5clust_minuslcc.jpeg", plot=GG1b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_2
WOTHpts.gw.exp.2.xy<-ggwr_expon2$SDF@coords[,1:2]
WOTHpts.gw.exp.2.pred<-ggwr_expon2$SDF@data[,1:10]

WOTHpts.gw.exp.2.Y<-ggwr_expon2$SDF@data[,14]
WOTHpts.gw.exp.2<-cbind(WOTHpts.gw.exp.2.xy, WOTHpts.gw.exp.2.pred, WOTHpts.gw.exp.2.Y)
names(WOTHpts.gw.exp.2)
str(WOTHpts.gw.exp.2)
WOTHpts.gw.exp.2<-WOTHpts.gw.exp.2[WOTHpts.gw.exp.2$WOTHpts.gw.exp.2.Y>0,]
names(WOTHpts.gw.exp.2)
str(WOTHpts.gw.exp.2)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.2[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.2[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.2[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.2.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 2")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.2.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 2")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.2.clust<-cbind(WOTHpts.gw.exp.2, cluster.assignment)

WOTHpts.gw.exp.2.clust.gath<-WOTHpts.gw.exp.2.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.2.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG2<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 2") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.2.effectsize.5clust.jpeg", plot=GG2, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG2b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 2") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.2.effectsize.5clust_minuslcc.jpeg", plot=GG2b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_3
WOTHpts.gw.exp.3.xy<-ggwr_expon3$SDF@coords[,1:2]
WOTHpts.gw.exp.3.pred<-ggwr_expon3$SDF@data[,1:10]

WOTHpts.gw.exp.3.Y<-ggwr_expon3$SDF@data[,14]
WOTHpts.gw.exp.3<-cbind(WOTHpts.gw.exp.3.xy, WOTHpts.gw.exp.3.pred, WOTHpts.gw.exp.3.Y)
names(WOTHpts.gw.exp.3)
str(WOTHpts.gw.exp.3)
WOTHpts.gw.exp.3<-WOTHpts.gw.exp.3[WOTHpts.gw.exp.3$WOTHpts.gw.exp.3.Y>0,]
names(WOTHpts.gw.exp.3)
str(WOTHpts.gw.exp.3)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.3[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.3[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.3[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.3.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 3")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.3.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 3")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.3.clust<-cbind(WOTHpts.gw.exp.3, cluster.assignment)

WOTHpts.gw.exp.3.clust.gath<-WOTHpts.gw.exp.3.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.3.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG3<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 3") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.3.effectsize.5clust.jpeg", plot=GG3, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG3b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 3") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.3.effectsize.5clust_minuslcc.jpeg", plot=GG3b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_4
WOTHpts.gw.exp.4.xy<-ggwr_expon4$SDF@coords[,1:2]
WOTHpts.gw.exp.4.pred<-ggwr_expon4$SDF@data[,1:10]

WOTHpts.gw.exp.4.Y<-ggwr_expon4$SDF@data[,14]
WOTHpts.gw.exp.4<-cbind(WOTHpts.gw.exp.4.xy, WOTHpts.gw.exp.4.pred, WOTHpts.gw.exp.4.Y)
names(WOTHpts.gw.exp.4)
str(WOTHpts.gw.exp.4)
WOTHpts.gw.exp.4<-WOTHpts.gw.exp.4[WOTHpts.gw.exp.4$WOTHpts.gw.exp.4.Y>0,]
names(WOTHpts.gw.exp.4)
str(WOTHpts.gw.exp.4)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.4[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.4[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.4[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.4.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 4")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.4.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 4")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.4.clust<-cbind(WOTHpts.gw.exp.4, cluster.assignment)

WOTHpts.gw.exp.4.clust.gath<-WOTHpts.gw.exp.4.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.4.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG4<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 4") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.4.effectsize.5clust.jpeg", plot=GG4, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG4b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 4") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.4.effectsize.5clust_minuslcc.jpeg", plot=GG4b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_5
WOTHpts.gw.exp.5.xy<-ggwr_expon5$SDF@coords[,1:2]
WOTHpts.gw.exp.5.pred<-ggwr_expon5$SDF@data[,1:10]

WOTHpts.gw.exp.5.Y<-ggwr_expon5$SDF@data[,14]
WOTHpts.gw.exp.5<-cbind(WOTHpts.gw.exp.5.xy, WOTHpts.gw.exp.5.pred, WOTHpts.gw.exp.5.Y)
names(WOTHpts.gw.exp.5)
str(WOTHpts.gw.exp.5)
WOTHpts.gw.exp.5<-WOTHpts.gw.exp.5[WOTHpts.gw.exp.5$WOTHpts.gw.exp.5.Y>0,]
names(WOTHpts.gw.exp.5)
str(WOTHpts.gw.exp.5)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.5[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.5[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.5[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.5.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 5")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.5.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 5")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.5.clust<-cbind(WOTHpts.gw.exp.5, cluster.assignment)

WOTHpts.gw.exp.5.clust.gath<-WOTHpts.gw.exp.5.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.5.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG5<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 5") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.5.effectsize.5clust.jpeg", plot=GG5, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG5b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 5") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.5.effectsize.5clust_minuslcc.jpeg", plot=GG5b, width=12, height=6, units=c("in"), dpi=300)



#GGWR_EXPON_6
WOTHpts.gw.exp.6.xy<-ggwr_expon6$SDF@coords[,1:2]
WOTHpts.gw.exp.6.pred<-ggwr_expon6$SDF@data[,1:10]

WOTHpts.gw.exp.6.Y<-ggwr_expon6$SDF@data[,14]
WOTHpts.gw.exp.6<-cbind(WOTHpts.gw.exp.6.xy, WOTHpts.gw.exp.6.pred, WOTHpts.gw.exp.6.Y)
names(WOTHpts.gw.exp.6)
str(WOTHpts.gw.exp.6)
WOTHpts.gw.exp.6<-WOTHpts.gw.exp.6[WOTHpts.gw.exp.6$WOTHpts.gw.exp.6.Y>0,]
names(WOTHpts.gw.exp.6)
str(WOTHpts.gw.exp.6)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.6[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.6[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.6[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.6.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 6")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.6.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 6")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.6.clust<-cbind(WOTHpts.gw.exp.6, cluster.assignment)

WOTHpts.gw.exp.6.clust.gath<-WOTHpts.gw.exp.6.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.6.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG6<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 6") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.6.effectsize.5clust.jpeg", plot=GG6, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG6b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 6") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.6.effectsize.5clust_minuslcc.jpeg", plot=GG6b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_7
WOTHpts.gw.exp.7.xy<-ggwr_expon7$SDF@coords[,1:2]
WOTHpts.gw.exp.7.pred<-ggwr_expon7$SDF@data[,1:10]

WOTHpts.gw.exp.7.Y<-ggwr_expon7$SDF@data[,14]
WOTHpts.gw.exp.7<-cbind(WOTHpts.gw.exp.7.xy, WOTHpts.gw.exp.7.pred, WOTHpts.gw.exp.7.Y)
names(WOTHpts.gw.exp.7)
str(WOTHpts.gw.exp.7)
WOTHpts.gw.exp.7<-WOTHpts.gw.exp.7[WOTHpts.gw.exp.7$WOTHpts.gw.exp.7.Y>0,]
names(WOTHpts.gw.exp.7)
str(WOTHpts.gw.exp.7)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.7[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.7[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.7[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.7.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 7")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.7.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 7")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.7.clust<-cbind(WOTHpts.gw.exp.7, cluster.assignment)

WOTHpts.gw.exp.7.clust.gath<-WOTHpts.gw.exp.7.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.7.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG7<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 7") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.7.effectsize.5clust.jpeg", plot=GG7, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG7b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 7") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.7.effectsize.5clust_minuslcc.jpeg", plot=GG7b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_8
WOTHpts.gw.exp.8.xy<-ggwr_expon8$SDF@coords[,1:2]
WOTHpts.gw.exp.8.pred<-ggwr_expon8$SDF@data[,1:10]

WOTHpts.gw.exp.8.Y<-ggwr_expon8$SDF@data[,14]
WOTHpts.gw.exp.8<-cbind(WOTHpts.gw.exp.8.xy, WOTHpts.gw.exp.8.pred, WOTHpts.gw.exp.8.Y)
names(WOTHpts.gw.exp.8)
str(WOTHpts.gw.exp.8)
WOTHpts.gw.exp.8<-WOTHpts.gw.exp.8[WOTHpts.gw.exp.8$WOTHpts.gw.exp.8.Y>0,]
names(WOTHpts.gw.exp.8)
str(WOTHpts.gw.exp.8)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.8[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.8[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.8[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.8.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 8")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.8.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 8")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.8.clust<-cbind(WOTHpts.gw.exp.8, cluster.assignment)

WOTHpts.gw.exp.8.clust.gath<-WOTHpts.gw.exp.8.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.8.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG8<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 8") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.8.effectsize.5clust.jpeg", plot=GG8, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG8b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 8") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.8.effectsize.5clust_minuslcc.jpeg", plot=GG8b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_9
WOTHpts.gw.exp.9.xy<-ggwr_expon9$SDF@coords[,1:2]
WOTHpts.gw.exp.9.pred<-ggwr_expon9$SDF@data[,1:10]

WOTHpts.gw.exp.9.Y<-ggwr_expon9$SDF@data[,14]
WOTHpts.gw.exp.9<-cbind(WOTHpts.gw.exp.9.xy, WOTHpts.gw.exp.9.pred, WOTHpts.gw.exp.9.Y)
names(WOTHpts.gw.exp.9)
str(WOTHpts.gw.exp.9)
WOTHpts.gw.exp.9<-WOTHpts.gw.exp.9[WOTHpts.gw.exp.9$WOTHpts.gw.exp.9.Y>0,]
names(WOTHpts.gw.exp.9)
str(WOTHpts.gw.exp.9)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.9[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.9[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.9[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-19500,2322000), ylim=c(5717000,6947500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.9.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 9")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.9.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 9")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.9.clust<-cbind(WOTHpts.gw.exp.9, cluster.assignment)

WOTHpts.gw.exp.9.clust.gath<-WOTHpts.gw.exp.9.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.9.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG9<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 9") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.9.effectsize.5clust.jpeg", plot=GG9, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG9b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 9") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.9.effectsize.5clust_minuslcc.jpeg", plot=GG9b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_10
WOTHpts.gw.exp.10.xy<-ggwr_expon10$SDF@coords[,1:2]
WOTHpts.gw.exp.10.pred<-ggwr_expon10$SDF@data[,1:10]

WOTHpts.gw.exp.10.Y<-ggwr_expon10$SDF@data[,14]
WOTHpts.gw.exp.10<-cbind(WOTHpts.gw.exp.10.xy, WOTHpts.gw.exp.10.pred, WOTHpts.gw.exp.10.Y)
names(WOTHpts.gw.exp.10)
str(WOTHpts.gw.exp.10)
WOTHpts.gw.exp.10<-WOTHpts.gw.exp.10[WOTHpts.gw.exp.10$WOTHpts.gw.exp.10.Y>0,]
names(WOTHpts.gw.exp.10)
str(WOTHpts.gw.exp.10)

mclustBIC5<- mclustBIC(data=WOTHpts.gw.exp.10[,3:12],G=1:5)
mclustMOD5<- Mclust(data=WOTHpts.gw.exp.10[,3:12],G=1:5, x=mclustBIC5, modelName = "VVV") 
summary(mclustMOD5)
plot(mclustMOD5)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.10[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD5$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-110500,2322000), ylim=c(5717000,61047500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.10.clusters5.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 10")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GGWR.expon.10.clusters5.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 10")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD5$classification
WOTHpts.gw.exp.10.clust<-cbind(WOTHpts.gw.exp.10, cluster.assignment)

WOTHpts.gw.exp.10.clust.gath<-WOTHpts.gw.exp.10.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 105%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.10.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG10<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 10") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.10.effectsize.5clust.jpeg", plot=GG10, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG10b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 10") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/GW.expon.10.effectsize.5clust_minuslcc.jpeg", plot=GG10b, width=12, height=6, units=c("in"), dpi=300)

#create multi-panel plot from PNG files
library(magick)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/Provincial maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/indivset_provmap_5clusters_collage.jpg",
    quality = 100
  )

pngfiles1b <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/BCR maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles1b) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/indivset_BCRmap_5clusters_collage.jpg",
    quality = 100
  )

pngfiles2 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/Effect Size Minus Land Cover",
    recursive = TRUE,
    pattern = "\\.jpeg$",
    full.names = T
  )

magick::image_read(pngfiles2) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpeg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/indivset_effectsize_5clusters_collage.jpg",
    quality = 100
  )


pngfiles2b <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/Effect Size Incl Land Cover",
    recursive = TRUE,
    pattern = "\\.jpeg$",
    full.names = T
  )

magick::image_read(pngfiles2b) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpeg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/indivset_effectsizelandcover_5clusters_collage.jpg",
    quality = 100
  )

pngfiles3 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/BIC plots",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles3) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("png") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 5 clust/indivset_BICplots_5clusters_collage.jpg",
    quality = 100
  )


#Seven clusters
#GGWR_EXPON_1
WOTHpts.gw.exp.1.xy<-ggwr_expon1$SDF@coords[,1:2]
WOTHpts.gw.exp.1.pred<-ggwr_expon1$SDF@data[,1:10]

WOTHpts.gw.exp.1.Y<-ggwr_expon1$SDF@data[,14]
WOTHpts.gw.exp.1<-cbind(WOTHpts.gw.exp.1.xy, WOTHpts.gw.exp.1.pred, WOTHpts.gw.exp.1.Y)
names(WOTHpts.gw.exp.1)
str(WOTHpts.gw.exp.1)
WOTHpts.gw.exp.1<-WOTHpts.gw.exp.1[WOTHpts.gw.exp.1$WOTHpts.gw.exp.1.Y>0,]
names(WOTHpts.gw.exp.1)
str(WOTHpts.gw.exp.1)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.1[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.1[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.1[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.1.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 1")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.1.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 1")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.1.clust<-cbind(WOTHpts.gw.exp.1, cluster.assignment)
library(tidyr)
library(plyr)
library(dplyr)
WOTHpts.gw.exp.1.clust.gath<-WOTHpts.gw.exp.1.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

library(Rmisc)
pd<-position_dodge(0.1)
# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.1.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG1<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 1") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.1.effectsize.7clust.jpeg", plot=GG1, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG1b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 1") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.1.effectsize.7clust_minuslcc.jpeg", plot=GG1b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_2
WOTHpts.gw.exp.2.xy<-ggwr_expon2$SDF@coords[,1:2]
WOTHpts.gw.exp.2.pred<-ggwr_expon2$SDF@data[,1:10]

WOTHpts.gw.exp.2.Y<-ggwr_expon2$SDF@data[,14]
WOTHpts.gw.exp.2<-cbind(WOTHpts.gw.exp.2.xy, WOTHpts.gw.exp.2.pred, WOTHpts.gw.exp.2.Y)
names(WOTHpts.gw.exp.2)
str(WOTHpts.gw.exp.2)
WOTHpts.gw.exp.2<-WOTHpts.gw.exp.2[WOTHpts.gw.exp.2$WOTHpts.gw.exp.2.Y>0,]
names(WOTHpts.gw.exp.2)
str(WOTHpts.gw.exp.2)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.2[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.2[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.2[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.2.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 2")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.2.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 2")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.2.clust<-cbind(WOTHpts.gw.exp.2, cluster.assignment)

WOTHpts.gw.exp.2.clust.gath<-WOTHpts.gw.exp.2.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.2.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG2<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 2") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.2.effectsize.7clust.jpeg", plot=GG2, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG2b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 2") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.2.effectsize.7clust_minuslcc.jpeg", plot=GG2b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_3
WOTHpts.gw.exp.3.xy<-ggwr_expon3$SDF@coords[,1:2]
WOTHpts.gw.exp.3.pred<-ggwr_expon3$SDF@data[,1:10]

WOTHpts.gw.exp.3.Y<-ggwr_expon3$SDF@data[,14]
WOTHpts.gw.exp.3<-cbind(WOTHpts.gw.exp.3.xy, WOTHpts.gw.exp.3.pred, WOTHpts.gw.exp.3.Y)
names(WOTHpts.gw.exp.3)
str(WOTHpts.gw.exp.3)
WOTHpts.gw.exp.3<-WOTHpts.gw.exp.3[WOTHpts.gw.exp.3$WOTHpts.gw.exp.3.Y>0,]
names(WOTHpts.gw.exp.3)
str(WOTHpts.gw.exp.3)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.3[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.3[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.3[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.3.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 3")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.3.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 3")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.3.clust<-cbind(WOTHpts.gw.exp.3, cluster.assignment)

WOTHpts.gw.exp.3.clust.gath<-WOTHpts.gw.exp.3.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.3.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG3<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 3") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.3.effectsize.7clust.jpeg", plot=GG3, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG3b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 3") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.3.effectsize.7clust_minuslcc.jpeg", plot=GG3b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_4
WOTHpts.gw.exp.4.xy<-ggwr_expon4$SDF@coords[,1:2]
WOTHpts.gw.exp.4.pred<-ggwr_expon4$SDF@data[,1:10]

WOTHpts.gw.exp.4.Y<-ggwr_expon4$SDF@data[,14]
WOTHpts.gw.exp.4<-cbind(WOTHpts.gw.exp.4.xy, WOTHpts.gw.exp.4.pred, WOTHpts.gw.exp.4.Y)
names(WOTHpts.gw.exp.4)
str(WOTHpts.gw.exp.4)
WOTHpts.gw.exp.4<-WOTHpts.gw.exp.4[WOTHpts.gw.exp.4$WOTHpts.gw.exp.4.Y>0,]
names(WOTHpts.gw.exp.4)
str(WOTHpts.gw.exp.4)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.4[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.4[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.4[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.4.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 4")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.4.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 4")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.4.clust<-cbind(WOTHpts.gw.exp.4, cluster.assignment)

WOTHpts.gw.exp.4.clust.gath<-WOTHpts.gw.exp.4.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.4.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG4<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 4") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.4.effectsize.7clust.jpeg", plot=GG4, width=12, height=6, units=c("in"), dpi=300)


tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG4b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 4") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.4.effectsize.7clust_minuslcc.jpeg", plot=GG4b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_5
WOTHpts.gw.exp.5.xy<-ggwr_expon5$SDF@coords[,1:2]
WOTHpts.gw.exp.5.pred<-ggwr_expon5$SDF@data[,1:10]

WOTHpts.gw.exp.5.Y<-ggwr_expon5$SDF@data[,14]
WOTHpts.gw.exp.5<-cbind(WOTHpts.gw.exp.5.xy, WOTHpts.gw.exp.5.pred, WOTHpts.gw.exp.5.Y)
names(WOTHpts.gw.exp.5)
str(WOTHpts.gw.exp.5)
WOTHpts.gw.exp.5<-WOTHpts.gw.exp.5[WOTHpts.gw.exp.5$WOTHpts.gw.exp.5.Y>0,]
names(WOTHpts.gw.exp.5)
str(WOTHpts.gw.exp.5)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.5[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.5[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.5[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.5.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 5")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.5.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 5")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.5.clust<-cbind(WOTHpts.gw.exp.5, cluster.assignment)

WOTHpts.gw.exp.5.clust.gath<-WOTHpts.gw.exp.5.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.5.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG5<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 5") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.5.effectsize.7clust.jpeg", plot=GG5, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG5b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 5") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.5.effectsize.7clust_minuslcc.jpeg", plot=GG5b, width=12, height=6, units=c("in"), dpi=300)



#GGWR_EXPON_6
WOTHpts.gw.exp.6.xy<-ggwr_expon6$SDF@coords[,1:2]
WOTHpts.gw.exp.6.pred<-ggwr_expon6$SDF@data[,1:10]

WOTHpts.gw.exp.6.Y<-ggwr_expon6$SDF@data[,14]
WOTHpts.gw.exp.6<-cbind(WOTHpts.gw.exp.6.xy, WOTHpts.gw.exp.6.pred, WOTHpts.gw.exp.6.Y)
names(WOTHpts.gw.exp.6)
str(WOTHpts.gw.exp.6)
WOTHpts.gw.exp.6<-WOTHpts.gw.exp.6[WOTHpts.gw.exp.6$WOTHpts.gw.exp.6.Y>0,]
names(WOTHpts.gw.exp.6)
str(WOTHpts.gw.exp.6)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.6[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.6[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.6[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.6.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 6")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.6.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 6")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.6.clust<-cbind(WOTHpts.gw.exp.6, cluster.assignment)

WOTHpts.gw.exp.6.clust.gath<-WOTHpts.gw.exp.6.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.6.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG6<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 6") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.6.effectsize.7clust.jpeg", plot=GG6, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG6b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 6") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.6.effectsize.7clust_minuslcc.jpeg", plot=GG6b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_7
WOTHpts.gw.exp.7.xy<-ggwr_expon7$SDF@coords[,1:2]
WOTHpts.gw.exp.7.pred<-ggwr_expon7$SDF@data[,1:10]

WOTHpts.gw.exp.7.Y<-ggwr_expon7$SDF@data[,14]
WOTHpts.gw.exp.7<-cbind(WOTHpts.gw.exp.7.xy, WOTHpts.gw.exp.7.pred, WOTHpts.gw.exp.7.Y)
names(WOTHpts.gw.exp.7)
str(WOTHpts.gw.exp.7)
WOTHpts.gw.exp.7<-WOTHpts.gw.exp.7[WOTHpts.gw.exp.7$WOTHpts.gw.exp.7.Y>0,]
names(WOTHpts.gw.exp.7)
str(WOTHpts.gw.exp.7)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.7[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.7[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.7[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.7.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 7")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.7.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 7")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.7.clust<-cbind(WOTHpts.gw.exp.7, cluster.assignment)

WOTHpts.gw.exp.7.clust.gath<-WOTHpts.gw.exp.7.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.7.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG7<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 7") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.7.effectsize.7clust.jpeg", plot=GG7, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG7b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 7") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.7.effectsize.7clust_minuslcc.jpeg", plot=GG7b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_8
WOTHpts.gw.exp.8.xy<-ggwr_expon8$SDF@coords[,1:2]
WOTHpts.gw.exp.8.pred<-ggwr_expon8$SDF@data[,1:10]

WOTHpts.gw.exp.8.Y<-ggwr_expon8$SDF@data[,14]
WOTHpts.gw.exp.8<-cbind(WOTHpts.gw.exp.8.xy, WOTHpts.gw.exp.8.pred, WOTHpts.gw.exp.8.Y)
names(WOTHpts.gw.exp.8)
str(WOTHpts.gw.exp.8)
WOTHpts.gw.exp.8<-WOTHpts.gw.exp.8[WOTHpts.gw.exp.8$WOTHpts.gw.exp.8.Y>0,]
names(WOTHpts.gw.exp.8)
str(WOTHpts.gw.exp.8)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.8[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.8[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.8[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-18500,2322000), ylim=c(5717000,6847500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.8.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 8")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.8.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 8")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.8.clust<-cbind(WOTHpts.gw.exp.8, cluster.assignment)

WOTHpts.gw.exp.8.clust.gath<-WOTHpts.gw.exp.8.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.8.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG8<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 8") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.8.effectsize.7clust.jpeg", plot=GG8, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG8b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 8") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.8.effectsize.7clust_minuslcc.jpeg", plot=GG8b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_9
WOTHpts.gw.exp.9.xy<-ggwr_expon9$SDF@coords[,1:2]
WOTHpts.gw.exp.9.pred<-ggwr_expon9$SDF@data[,1:10]

WOTHpts.gw.exp.9.Y<-ggwr_expon9$SDF@data[,14]
WOTHpts.gw.exp.9<-cbind(WOTHpts.gw.exp.9.xy, WOTHpts.gw.exp.9.pred, WOTHpts.gw.exp.9.Y)
names(WOTHpts.gw.exp.9)
str(WOTHpts.gw.exp.9)
WOTHpts.gw.exp.9<-WOTHpts.gw.exp.9[WOTHpts.gw.exp.9$WOTHpts.gw.exp.9.Y>0,]
names(WOTHpts.gw.exp.9)
str(WOTHpts.gw.exp.9)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.9[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.9[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.9[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-19500,2322000), ylim=c(5717000,6947500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.9.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 9")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.9.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 9")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.9.clust<-cbind(WOTHpts.gw.exp.9, cluster.assignment)

WOTHpts.gw.exp.9.clust.gath<-WOTHpts.gw.exp.9.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 95%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.9.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG9<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 9") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.9.effectsize.7clust.jpeg", plot=GG9, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG9b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 9") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.9.effectsize.7clust_minuslcc.jpeg", plot=GG9b, width=12, height=6, units=c("in"), dpi=300)


#GGWR_EXPON_10
WOTHpts.gw.exp.10.xy<-ggwr_expon10$SDF@coords[,1:2]
WOTHpts.gw.exp.10.pred<-ggwr_expon10$SDF@data[,1:10]

WOTHpts.gw.exp.10.Y<-ggwr_expon10$SDF@data[,14]
WOTHpts.gw.exp.10<-cbind(WOTHpts.gw.exp.10.xy, WOTHpts.gw.exp.10.pred, WOTHpts.gw.exp.10.Y)
names(WOTHpts.gw.exp.10)
str(WOTHpts.gw.exp.10)
WOTHpts.gw.exp.10<-WOTHpts.gw.exp.10[WOTHpts.gw.exp.10$WOTHpts.gw.exp.10.Y>0,]
names(WOTHpts.gw.exp.10)
str(WOTHpts.gw.exp.10)

mclustBIC7<- mclustBIC(data=WOTHpts.gw.exp.10[,3:12],G=1:7)
mclustMOD7<- Mclust(data=WOTHpts.gw.exp.10[,3:12],G=1:7, x=mclustBIC7, modelName = "VVV") 
summary(mclustMOD7)
plot(mclustMOD7)#Selection: 1

spdf3<-SpatialPointsDataFrame(coords=WOTHpts.gw.exp.10[,1:2],proj4string = latlong,data=data.frame(Classification=as.factor(mclustMOD7$classification)))
spdf3.lcc<-spTransform(spdf3, lcc_crs)
#spplot(spdf3, auto.key=FALSE, xlim=c(-110500,2322000), ylim=c(5717000,61047500))
#spplot(spdf3, auto.key=FALSE)
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.10.clusters7.bcr.png')
spplot(spdf3.lcc, sp.layout = list(list(BCRs.lcc, fill=NA, first=FALSE)), main="Sample 10")
dev.off()
png('E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GGWR.expon.10.clusters7.prov.png')
spplot(spdf3.lcc, sp.layout = list(list(woth.studyarea.sp, fill=NA, first=FALSE)), main="Sample 10")
dev.off()

#Plot effect sizes (mean+SD of each predictor effect size in each cluster)
cluster.assignment<-mclustMOD7$classification
WOTHpts.gw.exp.10.clust<-cbind(WOTHpts.gw.exp.10, cluster.assignment)

WOTHpts.gw.exp.10.clust.gath<-WOTHpts.gw.exp.10.clust %>%
  gather(elev:road, key=Predictor, value=EffectSize)

# summarySE provides the standard deviation, standard error of the mean, and a (default 105%) confidence interval
tgc <- summarySE(WOTHpts.gw.exp.10.clust.gath, measurevar="EffectSize", groupvars=c("cluster.assignment","Predictor"))
tgc

tgc$clusterassignment<-tgc$cluster.assignment
#to distinguish it from the vector called cluster.assignment

tgc$clusterassignment<-as.factor(tgc$clusterassignment)
GG10<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 10") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.10.effectsize.7clust.jpeg", plot=GG10, width=12, height=6, units=c("in"), dpi=300)

tgc<-tgc[!tgc$Predictor=="LCclass2Agr",]
tgc<-tgc[!tgc$Predictor=="LCclass2Barren+Shrub",]
tgc<-tgc[!tgc$Predictor=="LCclass2Conif",]
tgc<-tgc[!tgc$Predictor=="LCclass2Decid",]
tgc<-tgc[!tgc$Predictor=="LCclass2Devel+Wet",]
tgc<-tgc[!tgc$Predictor=="LCclass2Grass+Mixed",]
GG10b<-ggplot(tgc, aes(x=Predictor, y=EffectSize, colour=clusterassignment, group=clusterassignment)) + 
  geom_errorbar(aes(ymin=EffectSize-sd, ymax=EffectSize+sd, colour=clusterassignment), width=1, position=pd) +
  geom_point(aes(colour=clusterassignment, fill=clusterassignment), position=pd, size=3, shape=21) + # 21 is filled circle
  #scale_fill_manual(values=c("red","black","blue")) +         #
  xlab("Predictor") +
  ylab("Effect Size") +
  ggtitle("Sample 10") +
  #expand_limits(y=0) +
  my.theme+ #theme_bw() +
  theme(legend.position="bottom")               # Position legend in bottom right
ggsave("E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/GW.expon.10.effectsize.7clust_minuslcc.jpeg", plot=GG10b, width=12, height=6, units=c("in"), dpi=300)

#create multi-panel plot from PNG files
library(magick)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/Provincial maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/indivset_provmap_7clusters_collage.jpg",
    quality = 100
  )


pngfiles1b <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/BCR maps",
    recursive = TRUE,
    pattern = "\\.jpg$",
    full.names = T
  )

magick::image_read(pngfiles1b) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/indivset_BCRmap_7clusters_collage.jpg",
    quality = 100
  )

pngfiles2 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/Effect Size Minus Land Cover",
    recursive = TRUE,
    pattern = "\\.jpeg$",
    full.names = T
  )

magick::image_read(pngfiles2) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpeg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/indivset_effectsize_7clusters_collage.jpg",
    quality = 100
  )


pngfiles2b <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/Effect Size Incl Land Cover",
    recursive = TRUE,
    pattern = "\\.jpeg$",
    full.names = T
  )

magick::image_read(pngfiles2b) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpeg") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/indivset_effectsizelandcover_7clusters_collage.jpg",
    quality = 100
  )

pngfiles3 <-
  list.files(
    path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/BIC plots",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles3) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("png") %>%
  magick::image_write(
    format = ".tiff", path = "E:/CWS Wood Thrush Contract/CHID-GWmodel/2_outputs/GW sample dataset outputs/exponential/WOTH indiv sample 7 clust/indivset_BICplots_7clusters_collage.jpg",
    quality = 100
  )

#Create polygon shapefile describing Habitat Pattern Region (HPR)
#to use for regional Wood Thrush models.

#Based on cluster analyses and discussion of these results in 
#meetings, there is insufficient biological evidence from GW models
#for more than a single habitat pattern region to use in models.
#At all Wood Thrush occurrences in a habitat pattern region, Wood Thrush
#is assumed to respond similarly to individual and collective environmental
#features, and differently from Wood Thrush located in other 
#habitat pattern regions.

#All points with Wood Thrush that were sampled in GW models will
#be used to generate a single polygon shapefile, with boundaries
#created from a convex hull or through kernel density estimation.
#This polygon shapefile will be clipped to Bird Conservation Regions
#12, 13, and 14 within Canada.

df1<-read.csv("2_outputs/GW sample dataset outputs/exponential/GWmodelcoefficientsatsampledpointswithWOTH.csv", header=TRUE)
#Points projection = "+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 
#+lat_2=77 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs". I presume
#you can reproject these points to lat/long to link them
#with point count locations in original file

#13 predictors in df1: 10 to do with veg or land use or elevation
# based on BIC, when modelling a max of 3 clusters, 2 clusters gives a higher BIC therefore is "better"
# explanation of why highest BIC is best model in Mclust: https://stats.stackexchange.com/questions/237220/mclust-model-selection 

#create spatial data frame from regular data frame SScombo to extract GIS data
LCC <- CRS("+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

#create point shapefile for all WOTH locations used in GW models
GW.all<-SpatialPointsDataFrame(coords=df1[,c("x","y")],data=df1,proj4string = LCC)
GW.all.latlong<-spTransform(GW.all, CRS=latlong)

#convert actual occurrences to polygon for
#Habitat Pattern Region in Canada (just BCR 12, 13, 14)
XY.all.forhull<-as.data.frame(GW.all.latlong[,c("x","y")])
XY.all.forhull<-XY.all.forhull[,c("x.1","y.1")]
ch <- chull(XY.all.forhull[,c("x.1","y.1")])
coords <- XY.all.forhull[c(ch, ch[1]), ]  # closed polygon

sp_poly <- SpatialPolygons(list(Polygons(list(Polygon(coords)), ID=1)))
# set coordinate reference system with SpatialPolygons(..., proj4string=CRS(...))
# e.g. CRS("+proj=longlat +datum=WGS84")
sp_poly_df <- SpatialPolygonsDataFrame(sp_poly, data=data.frame(ID=1))
plot(GW.all.latlong, pch=19)
lines(sp_poly_df, col="red")#shows that polygon was created

#Now clip out just the part within Canada
basemap.laea<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap.latlong<-spTransform(basemap.laea, latlong)
Canada<-basemap.latlong[basemap.latlong$COUNTRY=="CAN",]
plot(GW.all.latlong, pch=19)
lines(sp_poly_df, col="red")#shows that polygon was created
lines(Canada, col="blue")#shows that polygon was created

WOTH.HPR.Canada<-raster::intersect(sp_poly_df,Canada)

#Now clip out the bit in BCRs 12, 13, 14
BCRs<- readOGR("E:/CWS Wood Thrush Contract/CHID-GWmodel/0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#in lat-long but slightly different proj4string
BCRs.latlong<-spTransform(BCRs, latlong)
BCRs.latlong.12.13.14<-BCRs.latlong[BCRs.latlong$BCR==12|
                                   BCRs.latlong$BCR==13|
                                   BCRs.latlong$BCR==14,]

WOTH.HPR.Canada.BCR.12.13.14<-raster::intersect(WOTH.HPR.Canada,
                                   BCRs.latlong.12.13.14)
plot(WOTH.HPR.Canada.BCR.12.13.14)
writeOGR(WOTH.HPR.Canada.BCR.12.13.14, "2_outputs/GW sample dataset outputs/exponential/WoodThrushSingleHabitatPatternRegionConvexHull", layer="WoodThrushSingleHabitatPatternRegionConvexHull", driver="ESRI Shapefile")

#Create polygon through kernel density estimation
#https://mhallwor.github.io/_pages/activities_GenerateTerritories

library(ks)
X.all.asif1territory<-c(GW.all.latlong)#creates a list of 1
bw<-lapply(X.all.asif1territory, FUN=function(x){ks::Hlscv(x@coords)})

WOTH_kde<-mapply(X.all.asif1territory,bw,
                 SIMPLIFY=FALSE,
                 FUN=function(x,y){
                   raster(kde(x@coords,h=y))
                 })

## ------------------------------------------------------------------------
# This code makes a custom function called getContour. 
# Inputs:
#    kde = kernel density estimate
#    prob = probabily - default is 0.95 (I switched it to 0.9999 for WOTH)

getContour <- function(kde, prob = 0.9999){
  # set all values 0 to NA
  kde[kde == 0]<-NA
  # create a vector of raster values
  kde_values <- raster::getValues(kde)
  # sort values 
  sortedValues <- sort(kde_values[!is.na(kde_values)],decreasing = TRUE)
  # find cumulative sum up to ith location
  sums <- cumsum(as.numeric(sortedValues))
  # binary response is value in the probabily zone or not
  p <- sum(sums <= prob * sums[length(sums)])
  # Set values in raster to 1 or 0
  kdeprob <- raster::setValues(kde, kde_values >= sortedValues[p])
  # return new kde
  return(kdeprob)
}

WOTH_9999kde <- lapply(WOTH_kde,
                       FUN = getContour,prob = 0.9999)

par(mfrow = c(1,2))
plot(WOTH_kde[[1]],legend = FALSE)
plot(WOTH_9999kde[[1]],legend = FALSE)

WOTH_9999poly <- lapply(WOTH_9999kde, 
                        FUN = function(x){
                          x[x==0]<-NA
                          y <- rasterToPolygons(x, dissolve = TRUE)
                          return(y)
                        })


WOTH_9999poly <- mapply(WOTH_9999poly, names(WOTH_9999poly), 
                        SIMPLIFY = FALSE,
                        FUN = function(x,y){x@polygons[[1]]@ID <- y
                        return(x)})


WOTH_9999poly <- do.call(rbind,WOTH_9999poly)

par(mfrow = c(1,1))
plot(WOTH_9999poly)
lines(sp_poly_df, col="red")#shows that polygon was created
lines(Canada, col="blue")#shows that polygon was created

WOTH.CdnrangeKDE<-raster::intersect(WOTH_9999poly,Canada)
plot(WOTH.CdnrangeKDE)
lines(sp_poly_df, col="red")#shows that polygon was created
lines(Canada, col="blue")#shows that polygon was created
lines(BCRs.latlong.12.13.14, col="green")

WOTH.HPR.KDE.BCR.12.13.14<-rgeos::gIntersection(WOTH.CdnrangeKDE,
                                                BCRs.latlong.12.13.14)

#Intersection failed; however, nearly all of the
#WOTH.CdnrangeKDE polygon falls within BCR 12, 13, or 14
writeOGR(WOTH.CdnrangeKDE, "2_outputs/GW sample dataset outputs/exponential/WoodThrushSingleHabitatPatternRegionKernelDensity", layer="WoodThrushSingleHabitatPatternRegionKernelDensity", driver="ESRI Shapefile")

WOTH.CdnrangeKDE<-readOGR("2_outputs/GW sample dataset outputs/exponential/WoodThrushSingleHabitatPatternRegionKernelDensity/WoodThrushSingleHabitatPatternRegionKernelDensity.shp") ## Basemap for point plots
plot(WOTH.CdnrangeKDE)